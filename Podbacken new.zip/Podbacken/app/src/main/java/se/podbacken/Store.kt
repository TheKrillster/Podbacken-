package se.podbacken

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Everything is kept on the phone as small JSON files. Private feed links never leave the phone. */
object Store {
    private fun dir(ctx: Context) = File(ctx.filesDir, "pod").apply { mkdirs() }
    private fun write(f: File, text: String) {
        val tmp = File(f.path + ".tmp")
        tmp.writeText(text)
        tmp.renameTo(f)
    }

    fun loadPodcasts(ctx: Context): List<Podcast> = runCatching {
        val arr = JSONArray(File(dir(ctx), "podcasts.json").readText())
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Podcast(o.getString("feed"), o.optString("title"), o.optString("author"), o.optString("image"), o.optString("desc"))
        }
    }.getOrDefault(emptyList())

    fun savePodcasts(ctx: Context, list: List<Podcast>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("feed", it.feedUrl).put("title", it.title).put("author", it.author).put("image", it.imageUrl).put("desc", it.description))
        }
        write(File(dir(ctx), "podcasts.json"), arr.toString())
    }

    private fun epFile(ctx: Context, feedUrl: String) = File(dir(ctx), "ep-${stableId(feedUrl)}.json")

    fun loadEpisodes(ctx: Context, feedUrl: String): List<Episode> = runCatching {
        val arr = JSONArray(epFile(ctx, feedUrl).readText())
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Episode(
                o.getString("id"), feedUrl, o.optString("title"), o.optLong("date"), o.optString("url"), o.optString("type"),
                o.optLong("dur"), o.optString("notes"), o.optString("image"), o.optString("chapters"), o.optInt("season"), o.optInt("num"),
            )
        }
    }.getOrDefault(emptyList())

    fun saveEpisodes(ctx: Context, feedUrl: String, list: List<Episode>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("title", it.title).put("date", it.dateMs).put("url", it.audioUrl).put("type", it.audioType)
                    .put("dur", it.durationSec).put("notes", it.notes).put("image", it.imageUrl).put("chapters", it.chaptersUrl)
                    .put("season", it.season).put("num", it.number)
            )
        }
        write(epFile(ctx, feedUrl), arr.toString())
    }

    fun deleteEpisodes(ctx: Context, feedUrl: String) { epFile(ctx, feedUrl).delete() }

    class State(val queue: List<String>, val played: Set<String>, val positions: Map<String, Long>)

    fun loadState(ctx: Context): State = runCatching {
        val o = JSONObject(File(dir(ctx), "state.json").readText())
        val q = o.optJSONArray("queue") ?: JSONArray()
        val pl = o.optJSONArray("played") ?: JSONArray()
        val pos = o.optJSONObject("positions") ?: JSONObject()
        State(
            (0 until q.length()).map { q.getString(it) },
            (0 until pl.length()).map { pl.getString(it) }.toSet(),
            pos.keys().asSequence().associateWith { pos.getLong(it) },
        )
    }.getOrDefault(State(emptyList(), emptySet(), emptyMap()))

    fun saveState(ctx: Context, queue: List<String>, played: Set<String>, positions: Map<String, Long>) {
        val pos = JSONObject()
        positions.forEach { (k, v) -> if (v > 0) pos.put(k, v) }
        write(
            File(dir(ctx), "state.json"),
            JSONObject().put("queue", JSONArray(queue)).put("played", JSONArray(played.toList())).put("positions", pos).toString(),
        )
    }
}
