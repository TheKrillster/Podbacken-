package se.podbacken.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import se.podbacken.Downloads
import se.podbacken.Episode
import se.podbacken.MainViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val sv = Locale.forLanguageTag("sv-SE")

fun fmtTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s / 60 % 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
}

fun fmtDur(sec: Long): String {
    val m = (sec + 30) / 60
    return when {
        sec <= 0 -> ""
        m >= 60 -> "${m / 60} h ${m % 60} min"
        else -> "$m min"
    }
}

fun fmtDate(ms: Long): String {
    if (ms <= 0) return ""
    val now = Calendar.getInstance()
    val then = Calendar.getInstance().apply { timeInMillis = ms }
    val days = ((now.timeInMillis - ms) / 86_400_000L)
    return when {
        days < 1 && now.get(Calendar.DAY_OF_YEAR) == then.get(Calendar.DAY_OF_YEAR) -> "I dag"
        days < 2 -> "I går"
        now.get(Calendar.YEAR) == then.get(Calendar.YEAR) -> SimpleDateFormat("d MMM", sv).format(Date(ms))
        else -> SimpleDateFormat("d MMM yyyy", sv).format(Date(ms))
    }
}

/** Show notes as HTML with clickable links; plain-text notes keep their line breaks. */
fun notesHtml(raw: String): String {
    var s = raw.replace(Regex("<img[^>]*>", RegexOption.IGNORE_CASE), "")
    if (!s.contains('<')) s = s.replace("\n", "<br>")
    return s
}

@Composable
fun Cover(url: String?, size: Dp, modifier: Modifier = Modifier, corner: Dp = 6.dp) {
    val c = LocalSkiv.current
    Box(modifier.size(size).clip(RoundedCornerShape(corner)).background(c.chip)) {
        if (!url.isNullOrEmpty()) {
            AsyncImage(model = url, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
    }
}

/** Round button that dips a little when pressed. */
@Composable
fun PressButton(
    onClick: () -> Unit,
    size: Dp,
    modifier: Modifier = Modifier,
    background: Color = Color.Transparent,
    content: @Composable BoxScope.() -> Unit,
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.86f else 1f, spring(dampingRatio = 0.45f, stiffness = 700f), label = "press")
    Box(
        modifier
            .size(size)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(CircleShape)
            .background(background)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
        content = content,
    )
}

@Composable
fun Chip(label: String, on: Boolean = false, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val c = LocalSkiv.current
    Text(
        label,
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(if (on) c.ink else c.chip)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp),
        fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold, color = if (on) c.panel else c.ink,
    )
}

/**
 * One episode. Swipe right: play next. Swipe left: last in the queue (or [leftAction] when given).
 * Long press for more. A translucent fill shows how far you have listened.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun EpisodeRow(
    vm: MainViewModel,
    e: Episode,
    showPodcast: Boolean,
    leftLabel: String = "Lägg sist i kön",
    leftAction: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    val c = LocalSkiv.current
    val pod = vm.podcast(e.feedUrl)
    val played = e.id in vm.played
    val now = e.id == vm.currentId
    val progress = vm.progressOf(e)
    val dl = vm.isDownloaded(e)
    val dlProgress = Downloads.progress[e.id]
    var menu by remember { mutableStateOf(false) }
    val state = rememberSwipeToDismissBoxState(confirmValueChange = { v ->
        when (v) {
            SwipeToDismissBoxValue.StartToEnd -> vm.playNext(e)
            SwipeToDismissBoxValue.EndToStart -> (leftAction ?: { vm.addToQueue(e) })()
            else -> Unit
        }
        false
    })
    SwipeToDismissBox(
        state = state,
        backgroundContent = {
            val right = state.dismissDirection == SwipeToDismissBoxValue.StartToEnd
            Row(
                Modifier.fillMaxSize().background(if (right) c.sticker else c.ink).padding(horizontal = 20.dp),
                horizontalArrangement = if (right) Arrangement.Start else Arrangement.End,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(if (right) "Spela härnäst" else leftLabel, fontWeight = FontWeight.SemiBold, color = if (right) c.stickerInk else c.panel)
            }
        },
    ) {
      Column(Modifier.fillMaxWidth()) {
        Box(Modifier.background(c.panel)) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .drawBehind {
                        if (progress in 0.001f..0.999f) {
                            drawRect(c.sticker.copy(alpha = 0.14f), size = Size(size.width * progress, size.height))
                        }
                    }
                    .combinedClickable(onClick = onClick, onLongClick = { menu = true })
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Cover(e.imageUrl.ifEmpty { pod?.imageUrl }, 54.dp)
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    val meta = listOfNotNull(
                        if (showPodcast) pod?.title else null,
                        fmtDate(e.dateMs).ifEmpty { null },
                        when {
                            played -> "Lyssnad"
                            progress > 0.001f && e.durationSec > 0 -> "${fmtDur((e.durationSec * (1 - progress)).toLong())} kvar"
                            else -> fmtDur(e.durationSec).ifEmpty { null }
                        },
                    ).joinToString(" · ")
                    Text(meta, fontSize = 12.sp, color = if (now) c.sticker else c.inkSoft, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        e.title, fontSize = 15.sp, lineHeight = 19.sp,
                        fontWeight = if (now) FontWeight.SemiBold else FontWeight.Medium,
                        color = when { now -> c.sticker; played -> c.inkSoft; else -> c.ink },
                        maxLines = 2, overflow = TextOverflow.Ellipsis,
                    )
                }
                Box(Modifier.padding(start = 8.dp), contentAlignment = Alignment.Center) {
                    when {
                        dlProgress != null -> Text("${(dlProgress * 100).toInt()} %", fontSize = 11.sp, color = c.inkSoft)
                        dl -> Glyph(Ic.Download, c.sticker, Modifier.size(18.dp))
                        e.id in vm.queue -> Text("I kö", fontSize = 11.sp, color = c.inkSoft)
                    }
                }
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Spela") }, onClick = { menu = false; vm.play(e) })
                DropdownMenuItem(text = { Text("Spela härnäst") }, onClick = { menu = false; vm.playNext(e) })
                DropdownMenuItem(text = { Text("Lägg sist i kön") }, onClick = { menu = false; vm.addToQueue(e) })
                DropdownMenuItem(
                    text = { Text(if (played) "Markera som ej lyssnad" else "Markera som lyssnad") },
                    onClick = { menu = false; vm.markPlayed(e, !played) },
                )
                if (dl) DropdownMenuItem(text = { Text("Ta bort nedladdning") }, onClick = { menu = false; vm.removeDownload(e) })
                else if (dlProgress == null) DropdownMenuItem(text = { Text("Ladda ner") }, onClick = { menu = false; vm.download(e) })
                if (pod != null) DropdownMenuItem(text = { Text("Gå till podden") }, onClick = { menu = false; vm.open(se.podbacken.Screen.PodcastView(pod.feedUrl)) })
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(c.line))
      }
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    val c = LocalSkiv.current
    Text(text, modifier = modifier.padding(start = 16.dp, top = 18.dp, bottom = 6.dp), fontSize = 11.sp, letterSpacing = 1.3.sp, color = c.inkSoft)
}
