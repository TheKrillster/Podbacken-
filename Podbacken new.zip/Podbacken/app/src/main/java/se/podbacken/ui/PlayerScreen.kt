package se.podbacken.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.first
import se.podbacken.Chapter
import se.podbacken.MainViewModel
import se.podbacken.Screen
import kotlin.math.sqrt

private val Speeds = listOf(0.8f, 1f, 1.2f, 1.5f, 1.8f, 2f)
private val Sleeps = listOf<Int?>(null, 15, 30, 45, 60, -1)

/** Full-screen player: the cassette on top, notes/chapters/queue below, buttons fixed at the bottom. */
@Composable
fun PlayerScreen(vm: MainViewModel) {
    val c = LocalSkiv.current
    val e = vm.current
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().background(c.panel).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            PressButton(onClick = { if (!vm.back()) vm.home(0) }, size = 48.dp) { Glyph(Ic.Down, c.ink, Modifier.size(26.dp)) }
            Text("Spelas nu", fontSize = 14.sp, color = c.inkSoft)
        }
        if (e == null) {
            Text("Inget avsnitt spelas. Välj ett i listan.", modifier = Modifier.padding(24.dp), fontSize = 17.sp, color = c.ink)
            return@Column
        }
        val pod = vm.podcast(e.feedUrl)
        val chapters by produceState<List<Chapter>>(emptyList(), e.id) { value = vm.chapters(e) }
        val progress = if (vm.durationMs > 0) (vm.positionMs.toFloat() / vm.durationMs).coerceIn(0f, 1f) else 0f

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Cassette(
                title = e.title, show = pod?.title ?: "", progress = progress, playing = vm.isPlaying,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp).fillMaxWidth(),
            )
            val tabs = buildList {
                add("Om avsnittet")
                if (chapters.isNotEmpty()) add("Kapitel")
                add(if (vm.queue.isEmpty()) "Kö" else "Kö · ${vm.queue.size}")
            }
            if (tab >= tabs.size) tab = 0
            Row(Modifier.padding(horizontal = 16.dp).padding(top = 12.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                tabs.forEachIndexed { i, t -> Chip(t, on = i == tab) { tab = i } }
            }
            when (tabs[tab]) {
                "Om avsnittet" -> Notes(e.notes)
                "Kapitel" -> ChapterList(chapters, vm.positionMs) { vm.seek(it) }
                else -> {
                    if (vm.queue.isEmpty()) {
                        Text("Kön är tom.", modifier = Modifier.padding(16.dp), fontSize = 15.sp, color = c.inkSoft)
                    }
                    vm.queue.forEach { id ->
                        vm.episode(id)?.let { q ->
                            EpisodeRow(vm, q, showPodcast = true, leftLabel = "Ta bort ur kön", leftAction = { vm.removeFromQueue(id) }) {
                                vm.open(Screen.EpisodeView(id))
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        Column(Modifier.fillMaxWidth().shadow(10.dp).background(c.panel).navigationBarsPadding().padding(top = 8.dp)) {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Text(e.title, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = c.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(pod?.title ?: "", fontSize = 13.sp, color = c.inkSoft, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            SeekBar(vm.positionMs, vm.durationMs, onSeek = { vm.seek(it) }, modifier = Modifier.padding(horizontal = 20.dp).padding(top = 4.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                val si = Speeds.indexOfFirst { kotlin.math.abs(it - vm.speed) < 0.01f }.coerceAtLeast(0)
                Chip(("%.1f×".format(vm.speed)).replace('.', ',')) { vm.changeSpeed(Speeds[(si + 1) % Speeds.size]) }
                PressButton(onClick = { vm.skip(-15) }, size = 52.dp) { SkipGlyph(back = true) }
                PressButton(onClick = { vm.toggle() }, size = 60.dp, background = c.sticker, modifier = Modifier.shadow(8.dp, CircleShape)) {
                    Crossfade(vm.isPlaying, label = "playpause") { p -> Glyph(if (p) Ic.Pause else Ic.Play, c.stickerInk, Modifier.size(28.dp)) }
                }
                PressButton(onClick = { vm.skip(30) }, size = 52.dp) { SkipGlyph(back = false) }
                val sleepLabel = when (val s = vm.sleepLeftMin) {
                    null -> "Sov"
                    -1 -> "Slutet"
                    else -> "$s min"
                }
                Chip(sleepLabel, on = vm.sleepLeftMin != null) {
                    val cur = Sleeps.indexOf(vm.sleepLeftMin.let { if (it != null && it > 0) Sleeps.filterNotNull().filter { s -> s > 0 }.firstOrNull { s -> s >= it } else it })
                    vm.setSleep(Sleeps[(cur + 1).coerceAtLeast(1) % Sleeps.size])
                }
            }
            Spacer(Modifier.height(4.dp))
        }
    }
}

@Composable
private fun SkipGlyph(back: Boolean) {
    val c = LocalSkiv.current
    Box(contentAlignment = Alignment.Center) {
        Glyph(if (back) Ic.ArcBack else Ic.ArcFwd, c.ink, Modifier.size(34.dp))
        Text(if (back) "15" else "30", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = c.ink, modifier = Modifier.padding(top = 2.dp))
    }
}

/** Thin timeline: tap or drag anywhere on it. */
@Composable
private fun SeekBar(positionMs: Long, durationMs: Long, onSeek: (Long) -> Unit, modifier: Modifier) {
    val c = LocalSkiv.current
    var drag by remember { mutableStateOf<Float?>(null) }
    val dur = durationMs.coerceAtLeast(1L)
    val frac = drag ?: (positionMs.toFloat() / dur).coerceIn(0f, 1f)
    Column(modifier.fillMaxWidth()) {
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(22.dp)
                .pointerInput(dur) { detectTapGestures { o -> onSeek(((o.x / size.width).coerceIn(0f, 1f) * dur).toLong()) } }
                .pointerInput(dur) {
                    detectHorizontalDragGestures(
                        onDragStart = { o -> drag = (o.x / size.width).coerceIn(0f, 1f) },
                        onDragEnd = { drag?.let { onSeek((it * dur).toLong()) }; drag = null },
                        onDragCancel = { drag = null },
                    ) { change, _ ->
                        change.consume()
                        drag = (change.position.x / size.width).coerceIn(0f, 1f)
                    }
                },
        ) {
            val h = if (drag != null) 6.dp.toPx() else 4.dp.toPx()
            val y = size.height / 2f - h / 2f
            drawRoundRect(c.line, Offset(0f, y), Size(size.width, h), CornerRadius(h))
            drawRoundRect(if (drag != null) c.sticker else c.ink, Offset(0f, y), Size(size.width * frac, h), CornerRadius(h))
            if (drag != null) drawCircle(c.sticker, 8.dp.toPx(), Offset(size.width * frac, size.height / 2f))
        }
        Row(Modifier.fillMaxWidth()) {
            Text(fmtTime((frac * dur).toLong()), fontSize = 11.sp, color = c.inkSoft, modifier = Modifier.weight(1f))
            Text("-" + fmtTime(((1f - frac) * dur).toLong()), fontSize = 11.sp, color = c.inkSoft)
        }
    }
}

/**
 * A compact cassette. The tape moves from the left reel to the right one as the episode plays,
 * and each hub turns faster the less tape it holds, like the real thing.
 */
@Composable
private fun Cassette(title: String, show: String, progress: Float, playing: Boolean, modifier: Modifier) {
    val c = LocalSkiv.current
    val playingState = rememberUpdatedState(playing)
    val progressState = rememberUpdatedState(progress)
    var angleL by remember { mutableFloatStateOf(0f) }
    var angleR by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        var run = 0f
        while (true) {
            if (!playingState.value && run < 0.02f) {
                run = 0f
                last = 0L
                snapshotFlow { playingState.value }.first { it }
            }
            withFrameNanos { now ->
                if (last != 0L) {
                    val dt = ((now - last) / 1e9f).coerceAtMost(0.1f)
                    run += ((if (playingState.value) 1f else 0f) - run) * (dt * 4f).coerceAtMost(1f)
                    val p = progressState.value
                    val rl = 0.35f + 0.65f * sqrt(1f - p)
                    val rr = 0.35f + 0.65f * sqrt(p)
                    // Constant tape speed: smaller reel → faster turn.
                    angleL = (angleL + run * dt * 70f / rl) % 360f
                    angleR = (angleR + run * dt * 70f / rr) % 360f
                }
                last = now
            }
        }
    }
    val body = lerp(c.deck, c.ink, 0.15f)
    val label = Color(0xFFEFE9DA)
    BoxWithConstraints(modifier.aspectRatio(1.58f)) {
        Canvas(Modifier.fillMaxSize().shadow(14.dp, androidx.compose.foundation.shape.RoundedCornerShape(14.dp))) {
            val w = size.width
            val h = size.height
            drawRoundRect(Brush.verticalGradient(listOf(lerp(body, Color.White, 0.08f), body)), size = size, cornerRadius = CornerRadius(w * 0.04f))
            // Screws.
            listOf(Offset(w * 0.04f, h * 0.06f), Offset(w * 0.96f, h * 0.06f), Offset(w * 0.04f, h * 0.94f), Offset(w * 0.96f, h * 0.94f), Offset(w * 0.5f, h * 0.9f))
                .forEach { screw(it, w * 0.018f) }
            // Label with a coloured band.
            val lt = Offset(w * 0.07f, h * 0.08f)
            val ls = Size(w * 0.86f, h * 0.60f)
            drawRoundRect(label, lt, ls, CornerRadius(w * 0.02f))
            drawRect(c.sticker, Offset(lt.x, lt.y + ls.height * 0.62f), Size(ls.width, ls.height * 0.10f))
            // Window.
            val wt = Offset(w * 0.25f, h * 0.30f)
            val ws = Size(w * 0.50f, h * 0.26f)
            drawRoundRect(Color(0xFF1A1A1A), wt, ws, CornerRadius(ws.height * 0.5f))
            val cl = Offset(w * 0.355f, wt.y + ws.height / 2f)
            val cr = Offset(w * 0.645f, wt.y + ws.height / 2f)
            val rMin = w * 0.048f
            val rMax = w * 0.125f
            val rl = rMin + (rMax - rMin) * sqrt(1f - progress)
            val rr = rMin + (rMax - rMin) * sqrt(progress)
            clipRect(wt.x, wt.y, wt.x + ws.width, wt.y + ws.height) {
                val tape = Color(0xFF4A3426)
                drawCircle(tape, rl, cl)
                drawCircle(tape, rr, cr)
                drawCircle(Color.White.copy(alpha = 0.06f), rl, cl, style = Stroke(1.dp.toPx()))
                drawCircle(Color.White.copy(alpha = 0.06f), rr, cr, style = Stroke(1.dp.toPx()))
            }
            hub(cl, rMin * 0.82f, angleL)
            hub(cr, rMin * 0.82f, angleR)
            // Tape running along the bottom, past the head.
            val tapeY = h * 0.80f
            drawPath(Path().apply {
                moveTo(cl.x - rl * 0.2f, cl.y + rl * 0.98f)
                lineTo(w * 0.22f, tapeY)
                lineTo(w * 0.78f, tapeY)
                lineTo(cr.x + rr * 0.2f, cr.y + rr * 0.98f)
            }, Color(0xFF4A3426), style = Stroke(1.6.dp.toPx()))
            // Bottom bridge with holes.
            drawPath(Path().apply {
                moveTo(w * 0.2f, h)
                lineTo(w * 0.26f, h * 0.76f)
                lineTo(w * 0.74f, h * 0.76f)
                lineTo(w * 0.8f, h)
                close()
            }, lerp(body, Color.Black, 0.25f))
            listOf(0.33f, 0.45f, 0.55f, 0.67f).forEach { fx -> drawCircle(Color(0xFF0E0E0E), w * 0.012f, Offset(w * fx, h * 0.88f)) }
        }
        Column(Modifier.fillMaxWidth().padding(horizontal = maxWidth * 0.1f).padding(top = maxWidth * 0.06f)) {
            Text(show.uppercase(), fontSize = 10.5.sp, letterSpacing = 0.12.em, color = Color(0xFF5A5A50), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(title, fontSize = 14.sp, lineHeight = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1C1C18), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

private fun DrawScope.screw(at: Offset, r: Float) {
    drawCircle(Color(0xFF8A8F94), r, at)
    drawLine(Color(0xFF3A3D40), Offset(at.x - r * 0.6f, at.y), Offset(at.x + r * 0.6f, at.y), r * 0.35f)
}

private fun DrawScope.hub(at: Offset, r: Float, angle: Float) {
    drawCircle(Color(0xFFF2F2F0), r, at)
    rotate(angle, at) {
        for (k in 0 until 6) {
            rotate(k * 60f, at) {
                drawRect(Color(0xFF2A2A2A), Offset(at.x - r * 0.12f, at.y - r * 0.92f), Size(r * 0.24f, r * 0.34f))
            }
        }
    }
    drawCircle(Color(0xFF2A2A2A), r * 0.42f, at)
}
