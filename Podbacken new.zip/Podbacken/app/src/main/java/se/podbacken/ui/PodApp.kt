package se.podbacken.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.zIndex
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import se.podbacken.MainViewModel
import se.podbacken.Screen

@Composable
fun PodApp(vm: MainViewModel) {
    val c = LocalSkiv.current
    BackHandler(enabled = vm.screen != Screen.Home(0)) {
        if (!vm.back()) vm.home(0)
    }
    Box(Modifier.fillMaxSize().background(c.panel)) {
        when (val s = vm.screen) {
            is Screen.Home -> Framed(vm, tabs = s.tab) { HomeContent(vm, s.tab) }
            is Screen.PodcastView -> Framed(vm) { PodcastScreen(vm, s.feedUrl) }
            is Screen.EpisodeView -> Framed(vm) { EpisodeScreen(vm, s.id) }
            Screen.Search -> Framed(vm) { SearchScreen(vm) }
            Screen.Settings -> Framed(vm) { SettingsScreen(vm) }
            Screen.Player -> PlayerScreen(vm)
        }
    }
}

/** Screen with the mini player (and on the start screen the tab bar) at the bottom. */
@Composable
private fun Framed(vm: MainViewModel, tabs: Int? = null, content: @Composable () -> Unit) {
    val c = LocalSkiv.current
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Box(Modifier.weight(1f).fillMaxWidth()) { content() }
        MiniPlayer(vm)
        if (tabs != null) {
            Box(Modifier.fillMaxWidth().height(1.dp).background(c.line))
            Row(Modifier.fillMaxWidth().background(c.panel).padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                listOf("Nytt", "Poddar", if (vm.queue.isEmpty()) "Kö" else "Kö · ${vm.queue.size}").forEachIndexed { i, label ->
                    val on = i == tabs
                    Text(
                        label,
                        modifier = Modifier.clip(RoundedCornerShape(50)).clickable { vm.home(i) }.padding(horizontal = 18.dp, vertical = 10.dp),
                        fontSize = 15.sp, fontWeight = if (on) FontWeight.ExtraBold else FontWeight.Medium,
                        color = if (on) c.sticker else c.inkSoft,
                    )
                }
            }
        }
        Spacer(Modifier.navigationBarsPadding())
    }
}

@Composable
fun TopBar(title: String, vm: MainViewModel, back: Boolean = true, actions: @Composable () -> Unit = {}) {
    val c = LocalSkiv.current
    Row(Modifier.fillMaxWidth().padding(start = if (back) 4.dp else 16.dp, end = 6.dp, top = 6.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        if (back) PressButton(onClick = { if (!vm.back()) vm.home(0) }, size = 44.dp) { Glyph(Ic.Back, c.ink, Modifier.size(24.dp)) }
        Text(title, modifier = Modifier.weight(1f), fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = c.ink, letterSpacing = (-0.02).em, maxLines = 1, overflow = TextOverflow.Ellipsis)
        actions()
    }
}

@Composable
private fun HomeContent(vm: MainViewModel, tab: Int) {
    val c = LocalSkiv.current
    Column(Modifier.fillMaxSize()) {
        TopBar("Podbacken", vm, back = false) {
            if (vm.refreshing) Text("Hämtar…", fontSize = 12.sp, color = c.inkSoft, modifier = Modifier.padding(end = 6.dp))
            else PressButton(onClick = { vm.refreshAll() }, size = 44.dp) { Glyph(Ic.Refresh, c.ink, Modifier.size(22.dp)) }
            PressButton(onClick = { vm.open(Screen.Search) }, size = 44.dp) { Glyph(Ic.Search, c.ink, Modifier.size(22.dp)) }
            PressButton(onClick = { vm.open(Screen.Settings) }, size = 44.dp) { Glyph(Ic.Settings, c.ink, Modifier.size(22.dp)) }
        }
        when {
            vm.podcasts.isEmpty() -> EmptyStart(vm)
            tab == 0 -> LazyColumn(Modifier.fillMaxSize()) {
                item { SwipeHint() }
                items(vm.latest, key = { it.id }) { e ->
                    EpisodeRow(vm, e, showPodcast = true) { vm.open(Screen.EpisodeView(e.id)) }
                }
            }
            tab == 1 -> PodcastGrid(vm)
            else -> QueueList(vm)
        }
    }
}

@Composable
private fun SwipeHint() {
    val c = LocalSkiv.current
    Text(
        "Svep höger för att spela härnäst, vänster för att lägga sist i kön. Håll för fler val.",
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp), fontSize = 12.5.sp, color = c.inkSoft,
    )
}

@Composable
private fun EmptyStart(vm: MainViewModel) {
    val c = LocalSkiv.current
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Lägg till din första podd", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = c.ink)
        Text(
            "Sök bland alla poddar, eller klistra in en RSS-länk, till exempel en privat länk från Patreon.",
            modifier = Modifier.padding(top = 8.dp, bottom = 16.dp), fontSize = 15.sp, color = c.inkSoft,
        )
        Chip("Sök eller lägg till", on = true) { vm.open(Screen.Search) }
    }
}

@Composable
private fun PodcastGrid(vm: MainViewModel) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Rutnät", "Lista", "Kassetter").forEachIndexed { i, l -> Chip(l, on = vm.podView == i) { vm.pickPodView(i) } }
        }
        when (vm.podView) {
            1 -> PodcastList(vm)
            2 -> CassetteShelf(vm)
            else -> ReorderGrid(vm)
        }
    }
}

/** Covers in a grid. Long-press and drag to put them in your own order. */
@Composable
private fun ReorderGrid(vm: MainViewModel) {
    val c = LocalSkiv.current
    val state = rememberLazyGridState()
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { mutableStateOf(Offset.Zero) }
    LazyVerticalGrid(
        columns = GridCells.Adaptive(104.dp),
        state = state,
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGesturesAfterLongPress(
                    onDragStart = { pos ->
                        state.layoutInfo.visibleItemsInfo.firstOrNull { item ->
                            val o = item.offset; val sz = item.size
                            pos.x >= o.x && pos.x <= o.x + sz.width && pos.y >= o.y && pos.y <= o.y + sz.height
                        }?.let { item -> (item.key as? String)?.takeIf { it != "add" }?.let { dragKey = it; dragOffset = Offset.Zero } }
                    },
                    onDrag = { change, amount ->
                        val key = dragKey ?: return@detectDragGesturesAfterLongPress
                        change.consume()
                        dragOffset += amount
                        val items = state.layoutInfo.visibleItemsInfo
                        val me = items.firstOrNull { it.key == key } ?: return@detectDragGesturesAfterLongPress
                        val center = Offset(me.offset.x + me.size.width / 2f, me.offset.y + me.size.height / 2f) + dragOffset
                        val target = items.firstOrNull { t ->
                            t.key != key && t.key != "add" &&
                                center.x >= t.offset.x && center.x <= t.offset.x + t.size.width &&
                                center.y >= t.offset.y && center.y <= t.offset.y + t.size.height
                        } ?: return@detectDragGesturesAfterLongPress
                        val from = vm.podcasts.indexOfFirst { it.feedUrl == key }
                        val to = vm.podcasts.indexOfFirst { it.feedUrl == target.key }
                        if (from >= 0 && to >= 0) {
                            // Keep the finger over the item after it jumps to its new slot.
                            dragOffset += Offset((me.offset.x - target.offset.x).toFloat(), (me.offset.y - target.offset.y).toFloat())
                            vm.movePodcast(from, to)
                        }
                    },
                    onDragEnd = { if (dragKey != null) vm.saveOrder(); dragKey = null; dragOffset = Offset.Zero },
                    onDragCancel = { dragKey = null; dragOffset = Offset.Zero },
                )
            },
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        items(vm.podcasts, key = { it.feedUrl }) { p ->
            val dragging = p.feedUrl == dragKey
            Column(
                Modifier
                    .zIndex(if (dragging) 1f else 0f)
                    .graphicsLayer {
                        if (dragging) {
                            translationX = dragOffset.x
                            translationY = dragOffset.y
                            scaleX = 1.06f
                            scaleY = 1.06f
                        }
                    }
                    .then(if (dragging) Modifier else Modifier.animateItem())
                    .clickable { vm.open(Screen.PodcastView(p.feedUrl)) },
            ) {
                Box(Modifier.fillMaxWidth().aspectRatio(1f).shadow(if (dragging) 16.dp else 6.dp, RoundedCornerShape(8.dp)).clip(RoundedCornerShape(8.dp))) {
                    Cover(p.imageUrl, 400.dp, Modifier.fillMaxSize(), corner = 8.dp)
                    val n = vm.newCount(p.feedUrl)
                    if (n > 0) {
                        Text(
                            "$n", modifier = Modifier.align(Alignment.TopEnd).padding(5.dp).clip(RoundedCornerShape(50))
                                .background(c.sticker).padding(horizontal = 7.dp, vertical = 2.dp),
                            fontSize = 11.sp, fontWeight = FontWeight.Bold, color = c.stickerInk,
                        )
                    }
                }
                Text(p.title, modifier = Modifier.padding(top = 6.dp), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = c.ink, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        item(key = "add") {
            Column(Modifier.clickable { vm.open(Screen.Search) }) {
                Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(8.dp)).background(c.chip), contentAlignment = Alignment.Center) {
                    Glyph(Ic.Plus, c.ink, Modifier.size(34.dp))
                }
                Text("Lägg till", modifier = Modifier.padding(top = 6.dp), fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = c.ink)
            }
        }
    }
}

@Composable
private fun PodcastList(vm: MainViewModel) {
    val c = LocalSkiv.current
    LazyColumn(Modifier.fillMaxSize()) {
        items(vm.podcasts, key = { it.feedUrl }) { p ->
            Row(
                Modifier.fillMaxWidth().clickable { vm.open(Screen.PodcastView(p.feedUrl)) }.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Cover(p.imageUrl, 56.dp)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(p.title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = c.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    val latest = vm.episodes[p.feedUrl]?.firstOrNull()
                    Text(
                        listOfNotNull(p.author.ifEmpty { null }, latest?.let { "Senast " + fmtDate(it.dateMs).lowercase() }).joinToString(" · "),
                        fontSize = 12.5.sp, color = c.inkSoft, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
                val n = vm.newCount(p.feedUrl)
                if (n > 0) Text("$n nya", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = c.sticker)
            }
            Box(Modifier.padding(start = 84.dp).fillMaxWidth().height(1.dp).background(c.line))
        }
        item { Box(Modifier.padding(16.dp)) { Chip("Lägg till podd") { vm.open(Screen.Search) } } }
    }
}

/** Every podcast as a cassette spine on a shelf. */
@Composable
private fun CassetteShelf(vm: MainViewModel) {
    val c = LocalSkiv.current
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item { Spacer(Modifier.height(4.dp)) }
        items(vm.podcasts, key = { it.feedUrl }) { p ->
            val hue = remember(p.feedUrl) { ((p.title.hashCode().toLong() and 0xffffffffL) % 360).toFloat() }
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .shadow(4.dp, RoundedCornerShape(4.dp))
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF26292A))
                    .clickable { vm.open(Screen.PodcastView(p.feedUrl)) }
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Cover(p.imageUrl, 42.dp, corner = 3.dp)
                Row(
                    Modifier.weight(1f).fillMaxHeight().padding(start = 8.dp).clip(RoundedCornerShape(2.dp))
                        .background(Color(0xFFEFE9DA)).padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.width(4.dp).fillMaxHeight().padding(vertical = 6.dp).background(Color.hsv(hue, 0.5f, 0.6f)))
                    Text(
                        p.title.uppercase(), modifier = Modifier.weight(1f).padding(start = 10.dp),
                        fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.06.em, color = Color(0xFF1C1C18),
                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                    val n = vm.newCount(p.feedUrl)
                    if (n > 0) Text("$n", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = c.sticker)
                }
            }
        }
        item { Box(Modifier.padding(vertical = 12.dp)) { Chip("Lägg till podd") { vm.open(Screen.Search) } } }
    }
}

@Composable
private fun QueueList(vm: MainViewModel) {
    val c = LocalSkiv.current
    val cur = vm.current
    LazyColumn(Modifier.fillMaxSize()) {
        if (cur != null) {
            item { SectionTitle("SPELAS NU") }
            item(key = "now") { EpisodeRow(vm, cur, showPodcast = true) { vm.open(Screen.Player) } }
        }
        item { SectionTitle("HÄRNÄST") }
        if (vm.queue.isEmpty()) {
            item {
                Text(
                    "Kön är tom. Svep höger på ett avsnitt för att spela det härnäst, eller vänster för att lägga det sist.",
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp), fontSize = 14.sp, color = c.inkSoft, textAlign = TextAlign.Start,
                )
            }
        }
        items(vm.queue, key = { "q:$it" }) { id ->
            val e = vm.episode(id) ?: return@items
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    EpisodeRow(vm, e, showPodcast = true, leftLabel = "Ta bort ur kön", leftAction = { vm.removeFromQueue(id) }) {
                        vm.open(Screen.EpisodeView(id))
                    }
                }
                Column(Modifier.width(40.dp)) {
                    PressButton(onClick = { vm.moveInQueue(id, -1) }, size = 36.dp) { Text("▲", fontSize = 13.sp, color = c.inkSoft) }
                    PressButton(onClick = { vm.moveInQueue(id, 1) }, size = 36.dp) { Text("▼", fontSize = 13.sp, color = c.inkSoft) }
                }
            }
        }
    }
}

@Composable
private fun MiniPlayer(vm: MainViewModel) {
    val c = LocalSkiv.current
    val e = vm.current ?: return
    val pod = vm.podcast(e.feedUrl)
    Column(Modifier.fillMaxWidth().background(c.panel)) {
        val frac = if (vm.durationMs > 0) (vm.positionMs.toFloat() / vm.durationMs).coerceIn(0f, 1f) else 0f
        Box(Modifier.fillMaxWidth().height(2.dp).background(c.line)) {
            Box(Modifier.fillMaxWidth(frac).height(2.dp).background(c.sticker))
        }
        Row(
            Modifier.fillMaxWidth().clickable { vm.open(Screen.Player) }.padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Cover(e.imageUrl.ifEmpty { pod?.imageUrl }, 44.dp)
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(e.title, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, color = c.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(pod?.title ?: "", fontSize = 12.5.sp, color = c.inkSoft, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            PressButton(onClick = { vm.skip(-15) }, size = 40.dp) { Glyph(Ic.ArcBack, c.ink, Modifier.size(22.dp)) }
            PressButton(onClick = { vm.toggle() }, size = 44.dp) { Glyph(if (vm.isPlaying) Ic.Pause else Ic.Play, c.ink, Modifier.size(24.dp)) }
        }
    }
}
