package se.podbacken

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.compose.runtime.mutableStateMapOf
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

/** Episodes saved on the phone for listening without a connection. */
object Downloads {
    /** Download progress 0..1 for episodes being fetched right now. */
    val progress = mutableStateMapOf<String, Float>()

    private fun dir(ctx: Context) = File(ctx.filesDir, "dl").apply { mkdirs() }
    fun file(ctx: Context, e: Episode) = File(dir(ctx), e.id + ".audio")
    fun has(ctx: Context, e: Episode) = file(ctx, e).exists()

    fun delete(ctx: Context, e: Episode) { file(ctx, e).delete() }

    /** Blocking; follows redirects (podcast hosts love them). */
    suspend fun fetch(ctx: Context, e: Episode): Boolean = withContext(Dispatchers.IO) {
        val target = file(ctx, e)
        if (target.exists()) return@withContext true
        val tmp = File(target.path + ".part")
        progress[e.id] = 0f
        try {
            var url = e.audioUrl
            var conn: HttpURLConnection? = null
            var hops = 0
            while (true) {
                val c = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20_000
                    readTimeout = 60_000
                    instanceFollowRedirects = false
                    setRequestProperty("User-Agent", "Podbacken/1.0 (Android podcast player)")
                }
                val code = c.responseCode
                if (code in 301..308 && hops++ < 10) {
                    url = URL(URL(url), c.getHeaderField("Location")).toString()
                    c.disconnect()
                    continue
                }
                if (code != 200) { c.disconnect(); return@withContext false }
                conn = c
                break
            }
            val c = conn ?: return@withContext false
            val total = c.contentLengthLong
            c.inputStream.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) progress[e.id] = done.toFloat() / total
                    }
                }
            }
            c.disconnect()
            tmp.renameTo(target)
        } catch (ex: Exception) {
            tmp.delete()
            false
        } finally {
            progress.remove(e.id)
        }
    }

    // ---------- automatic downloads ----------

    private const val PREFS = "podbacken"

    fun autoFeeds(ctx: Context): Set<String> =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getStringSet("autoDl", null)?.toSet() ?: emptySet()

    fun notifyFeeds(ctx: Context): Set<String> =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getStringSet("notify", null)?.toSet() ?: emptySet()

    fun setAuto(ctx: Context, feedUrl: String, on: Boolean) {
        val now = autoFeeds(ctx).let { if (on) it + feedUrl else it - feedUrl }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putStringSet("autoDl", now).apply()
        schedule(ctx)
    }

    fun setNotify(ctx: Context, feedUrl: String, on: Boolean) {
        val now = notifyFeeds(ctx).let { if (on) it + feedUrl else it - feedUrl }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putStringSet("notify", now).apply()
        schedule(ctx)
    }

    /** Checks feeds every ~4 hours while any podcast has downloads or notices switched on. */
    fun schedule(ctx: Context) {
        val wm = WorkManager.getInstance(ctx)
        if (autoFeeds(ctx).isEmpty() && notifyFeeds(ctx).isEmpty()) { wm.cancelUniqueWork("autoDl"); return }
        val req = PeriodicWorkRequestBuilder<AutoDownloadWorker>(4, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        wm.enqueueUniquePeriodicWork("autoDl", ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    private fun onWifi(ctx: Context): Boolean {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return false
        return !cm.isActiveNetworkMetered
    }

    private const val CHANNEL = "new_episodes"

    private fun notifyNew(ctx: Context, pod: Podcast, eps: List<Episode>) {
        if (eps.isEmpty()) return
        if (ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Nya avsnitt", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val text = if (eps.size == 1) eps[0].title else "${eps.size} nya avsnitt: " + eps.joinToString(" · ") { it.title }
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(pod.title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        runCatching { NotificationManagerCompat.from(ctx).notify(pod.feedUrl.hashCode(), n) }
    }

    /**
     * For podcasts with automatic downloads: fetch episodes that are new since last check
     * (at most the 2 newest per podcast), and remove downloads that have been listened to.
     */
    suspend fun runAuto(ctx: Context) {
        val auto = autoFeeds(ctx)
        val notify = notifyFeeds(ctx)
        val wifi = onWifi(ctx)
        val state = Store.loadState(ctx)
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        for (pod in Store.loadPodcasts(ctx)) {
            val old = Store.loadEpisodes(ctx, pod.feedUrl)
            val fresh = runCatching { FeedParser.parse(pod.feedUrl, Http.get(pod.feedUrl)).second }.getOrNull() ?: old
            if (fresh !== old) Store.saveEpisodes(ctx, pod.feedUrl, fresh)
            if (pod.feedUrl in auto || pod.feedUrl in notify) {
                val seenKey = "seen:" + stableId(pod.feedUrl)
                val seen = prefs.getStringSet(seenKey, null) ?: old.map { it.id }.toSet()
                val newOnes = fresh.filter { it.id !in seen && it.id !in state.played }
                if (pod.feedUrl in notify) notifyNew(ctx, pod, newOnes.take(5))
                if (pod.feedUrl in auto && wifi) newOnes.take(2).forEach { fetch(ctx, it) }
                prefs.edit().putStringSet(seenKey, fresh.map { it.id }.toSet()).apply()
            }
        }
        cleanPlayed(ctx, state.played)
    }

    fun cleanPlayed(ctx: Context, played: Set<String>) {
        dir(ctx).listFiles()?.forEach { f ->
            if (f.name.removeSuffix(".audio") in played) f.delete()
        }
    }
}

class AutoDownloadWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        runCatching { Downloads.runAuto(applicationContext) }
        return Result.success()
    }
}
