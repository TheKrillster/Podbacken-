# Podbacken

Poddspelare för Android 11 eller nyare: sök poddar, lägg till privata RSS-länkar (till exempel Patreon), kö med swipe, nedladdning, automatisk nedladdning och aviseringar för nya avsnitt, shownotes, kapitel, hastighet och insomningstimer.

Bygg som Skivbacken: ladda upp Podbacken.zip till ett eget GitHub-projekt med byggfilen `.github/workflows/build.yml`, och hämta APK-filen under Releases.
