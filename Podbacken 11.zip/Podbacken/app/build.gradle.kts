plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "se.podbacken"
    compileSdk = 35

    defaultConfig {
        applicationId = "se.podbacken"
        minSdk = 30
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
    // A fixed key, so every new build can be installed over the previous one.
    signingConfigs {
        create("podbacken") {
            storeFile = file("podbacken.keystore")
            storePassword = "podbacken"
            keyAlias = "podbacken"
            keyPassword = "podbacken"
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("podbacken") }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("podbacken")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-session:1.5.1")
    implementation("io.coil-kt:coil-compose:2.7.0")
    implementation("androidx.work:work-runtime-ktx:2.10.0")
}
