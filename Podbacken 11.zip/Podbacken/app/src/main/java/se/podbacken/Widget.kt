package se.podbacken

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.RemoteViews
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken

/** Home-screen widget: cover, episode and podcast name, back 15 s, play/pause, forward 30 s. */
class PodWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        render(context, null)
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == ACT_PLAY || action == ACT_BACK || action == ACT_FWD) {
            val pending = goAsync()
            control(context.applicationContext, action) { pending.finish() }
            return
        }
        super.onReceive(context, intent)
    }

    companion object {
        const val ACT_PLAY = "se.podbacken.widget.PLAY"
        const val ACT_BACK = "se.podbacken.widget.BACK"
        const val ACT_FWD = "se.podbacken.widget.FWD"
        private const val PREFS = "podbacken_widget"

        /** Called by the playback service, so the widget can show and resume the last episode. */
        fun remember(ctx: Context, id: String, uri: String, title: String, show: String, art: String, positionMs: Long, playing: Boolean) {
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("id", id).putString("uri", uri).putString("title", title).putString("show", show)
                .putString("art", art).putLong("pos", positionMs).putBoolean("playing", playing)
                .apply()
        }

        fun markStopped(ctx: Context, positionMs: Long?) {
            val e = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("playing", false)
            if (positionMs != null) e.putLong("pos", positionMs)
            e.apply()
        }

        fun render(ctx: Context, art: Bitmap?) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, PodWidget::class.java))
            if (ids.isEmpty()) return
            val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val title = p.getString("title", null)?.takeIf { it.isNotEmpty() }
            val show = p.getString("show", null) ?: ""
            val playing = p.getBoolean("playing", false)

            val v = RemoteViews(ctx.packageName, R.layout.widget_pod)
            v.setTextViewText(R.id.w_title, title ?: "Podbacken")
            v.setTextViewText(R.id.w_show, if (title == null) "Välj ett avsnitt i appen" else show)
            v.setImageViewResource(R.id.w_play, if (playing) R.drawable.ic_w_pause else R.drawable.ic_w_play)
            if (art != null) v.setImageViewBitmap(R.id.w_cover, art) else v.setImageViewResource(R.id.w_cover, R.drawable.ic_w_cassette)

            val open = PendingIntent.getActivity(
                ctx, 10, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            v.setOnClickPendingIntent(R.id.w_info, open)
            v.setOnClickPendingIntent(R.id.w_cover, open)
            v.setOnClickPendingIntent(R.id.w_play, button(ctx, ACT_PLAY, 11))
            v.setOnClickPendingIntent(R.id.w_back, button(ctx, ACT_BACK, 12))
            v.setOnClickPendingIntent(R.id.w_fwd, button(ctx, ACT_FWD, 13))
            mgr.updateAppWidget(ids, v)
        }

        private fun button(ctx: Context, action: String, code: Int): PendingIntent =
            PendingIntent.getBroadcast(
                ctx, code, Intent(ctx, PodWidget::class.java).setAction(action),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )

        /** Connects to the player for a moment and gives it one command. */
        private fun control(ctx: Context, action: String, done: () -> Unit) {
            val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
            val future = MediaController.Builder(ctx, token).buildAsync()
            future.addListener({
                val c = runCatching { future.get() }.getOrNull()
                if (c != null) {
                    runCatching {
                        if (c.mediaItemCount == 0) resumeLast(ctx, c)
                        when (action) {
                            ACT_PLAY -> if (c.isPlaying) {
                                c.pause()
                            } else {
                                if (c.playbackState == Player.STATE_IDLE) c.prepare()
                                c.play()
                            }
                            ACT_BACK -> c.seekTo((c.currentPosition - 15_000L).coerceAtLeast(0L))
                            ACT_FWD -> {
                                val target = c.currentPosition + 30_000L
                                c.seekTo(if (c.duration > 0L) target.coerceAtMost(c.duration - 1_000L) else target)
                            }
                        }
                    }
                }
                Handler(Looper.getMainLooper()).postDelayed({
                    c?.release()
                    done()
                }, 1_500L)
            }, ContextCompat.getMainExecutor(ctx))
        }

        /** The app was closed: load the last episode again, at the place you stopped. */
        private fun resumeLast(ctx: Context, c: MediaController) {
            val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val id = p.getString("id", null) ?: return
            val uri = p.getString("uri", null)?.takeIf { it.isNotEmpty() } ?: return
            val art = p.getString("art", null) ?: ""
            val md = MediaMetadata.Builder()
                .setTitle(p.getString("title", null))
                .setArtist(p.getString("show", null))
                .setAlbumTitle(p.getString("show", null))
            if (art.isNotEmpty()) md.setArtworkUri(Uri.parse(art))
            val item = MediaItem.Builder().setMediaId(id).setUri(Uri.parse(uri)).setMediaMetadata(md.build()).build()
            c.setMediaItem(item, p.getLong("pos", 0L))
            c.prepare()
        }
    }
}
