package se.podbacken

import android.app.PendingIntent
import android.content.Intent
import android.graphics.Bitmap
import androidx.core.graphics.drawable.toBitmap
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import coil.ImageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Plays with the screen off and gives lock-screen, headphone and widget controls. */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var artUrl: String? = null
    private var art: Bitmap? = null

    private val widgetListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            if (events.containsAny(
                    Player.EVENT_MEDIA_ITEM_TRANSITION,
                    Player.EVENT_IS_PLAYING_CHANGED,
                    Player.EVENT_MEDIA_METADATA_CHANGED,
                    Player.EVENT_POSITION_DISCONTINUITY,
                )
            ) {
                updateWidget(player)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_SPEECH).build(),
                true,
            )
            .setHandleAudioBecomingNoisy(true)
            .setSeekBackIncrementMs(15_000)
            .setSeekForwardIncrementMs(30_000)
            .build()
        player.addListener(widgetListener)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        session = MediaSession.Builder(this, player).setSessionActivity(open).build()
    }

    private fun updateWidget(p: Player) {
        val item = p.currentMediaItem ?: return
        val md = item.mediaMetadata
        val url = md.artworkUri?.toString()
        PodWidget.remember(
            this, item.mediaId, item.localConfiguration?.uri?.toString() ?: "",
            md.title?.toString() ?: "", md.artist?.toString() ?: "", url ?: "",
            p.currentPosition, p.isPlaying,
        )
        if (url != artUrl) {
            artUrl = url
            art = null
            if (url != null) {
                scope.launch {
                    val bmp = loadArt(url)
                    if (artUrl == url) {
                        art = bmp
                        PodWidget.render(this@PlaybackService, bmp)
                    }
                }
            }
        }
        PodWidget.render(this, art)
    }

    private suspend fun loadArt(url: String): Bitmap? = runCatching {
        val req = ImageRequest.Builder(this).data(url).size(240).allowHardware(false).build()
        val result = ImageLoader(this).execute(req)
        (result as? SuccessResult)?.drawable?.toBitmap(240, 240)
    }.getOrNull()

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        val p = session?.player
        PodWidget.markStopped(this, p?.currentPosition)
        PodWidget.render(this, art)
        scope.cancel()
        session?.run {
            player.removeListener(widgetListener)
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}
