package se.podbacken

import android.util.Xml
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Locale

data class Podcast(
    val feedUrl: String,
    val title: String,
    val author: String,
    val imageUrl: String,
    val description: String,
)

data class Episode(
    val id: String,
    val feedUrl: String,
    val title: String,
    val dateMs: Long,
    val audioUrl: String,
    val audioType: String,
    val durationSec: Long,
    /** Show notes as HTML (or plain text) straight from the feed. */
    val notes: String,
    val imageUrl: String,
    val chaptersUrl: String,
    val season: Int,
    val number: Int,
)

data class Chapter(val startMs: Long, val title: String, val url: String?)

data class SearchHit(val title: String, val author: String, val feedUrl: String, val imageUrl: String)

object Http {
    private const val UA = "Podbacken/1.0 (Android podcast player)"

    /** GET that follows redirects, also between http and https. */
    fun get(url: String): String {
        var current = url.trim()
        repeat(8) {
            val c = (URL(current).openConnection() as HttpURLConnection).apply {
                connectTimeout = 15_000
                readTimeout = 30_000
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", UA)
            }
            try {
                val code = c.responseCode
                if (code in 301..308) {
                    current = URL(URL(current), c.getHeaderField("Location") ?: throw java.io.IOException("Omdirigering utan adress")).toString()
                    return@repeat
                }
                if (code != 200) throw java.io.IOException("Servern svarade $code")
                return c.inputStream.bufferedReader().use { it.readText() }
            } finally {
                c.disconnect()
            }
        }
        throw java.io.IOException("För många omdirigeringar")
    }
}

fun stableId(vararg parts: String): String {
    val md = MessageDigest.getInstance("SHA-1").digest(parts.joinToString("\u0000").toByteArray())
    return md.take(10).joinToString("") { "%02x".format(it) }
}

object FeedParser {
    private val dateFormats = listOf(
        "EEE, dd MMM yyyy HH:mm:ss Z", "EEE, d MMM yyyy HH:mm:ss Z", "EEE, dd MMM yyyy HH:mm:ss zzz",
        "EEE, dd MMM yyyy HH:mm Z", "dd MMM yyyy HH:mm:ss Z", "yyyy-MM-dd'T'HH:mm:ssXXX", "yyyy-MM-dd",
    )

    private fun parseDate(s: String): Long {
        val t = s.trim()
        for (f in dateFormats) {
            runCatching { SimpleDateFormat(f, Locale.US).parse(t)?.time }.getOrNull()?.let { return it }
        }
        return 0L
    }

    /** "1:02:03", "62:03" or "3723" → seconds. */
    private fun parseDuration(s: String): Long {
        val parts = s.trim().split(":").mapNotNull { it.trim().toDoubleOrNull() }
        if (parts.isEmpty()) return 0
        return parts.fold(0.0) { acc, v -> acc * 60 + v }.toLong()
    }

    fun parse(feedUrl: String, xml: String): Pair<Podcast, List<Episode>> {
        val p = Xml.newPullParser()
        p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        p.setInput(xml.reader())

        var title = ""; var author = ""; var image = ""; var desc = ""
        val episodes = mutableListOf<Episode>()
        var inItem = false
        var inChannelImage = false
        // Current item fields.
        var iTitle = ""; var iGuid = ""; var iDate = 0L; var iUrl = ""; var iType = ""; var iDur = 0L
        var iDesc = ""; var iContent = ""; var iSummary = ""; var iImage = ""; var iChapters = ""; var iSeason = 0; var iNum = 0

        fun text(): String = runCatching { p.nextText() }.getOrDefault("").trim()

        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                val name = p.name.lowercase()
                if (name == "item" || name == "entry") {
                    inItem = true
                    iTitle = ""; iGuid = ""; iDate = 0L; iUrl = ""; iType = ""; iDur = 0L
                    iDesc = ""; iContent = ""; iSummary = ""; iImage = ""; iChapters = ""; iSeason = 0; iNum = 0
                } else if (inItem) {
                    when (name) {
                        "title" -> iTitle = text()
                        "guid", "id" -> iGuid = text()
                        "pubdate", "published", "dc:date" -> iDate = parseDate(text())
                        "enclosure" -> {
                            iUrl = p.getAttributeValue(null, "url") ?: iUrl
                            iType = p.getAttributeValue(null, "type") ?: ""
                        }
                        "itunes:duration" -> iDur = parseDuration(text())
                        "description" -> iDesc = text()
                        "content:encoded" -> iContent = text()
                        "itunes:summary" -> iSummary = text()
                        "itunes:image" -> iImage = p.getAttributeValue(null, "href") ?: iImage
                        "podcast:chapters" -> iChapters = p.getAttributeValue(null, "url") ?: ""
                        "itunes:season" -> iSeason = text().toIntOrNull() ?: 0
                        "itunes:episode" -> iNum = text().toIntOrNull() ?: 0
                    }
                } else {
                    when (name) {
                        "title" -> if (title.isEmpty() && !inChannelImage) title = text()
                        "itunes:author" -> if (author.isEmpty()) author = text()
                        "managingeditor", "itunes:name" -> if (author.isEmpty()) author = text()
                        "itunes:image" -> if (image.isEmpty()) image = p.getAttributeValue(null, "href") ?: ""
                        "image" -> inChannelImage = true
                        "url" -> if (inChannelImage && image.isEmpty()) image = text()
                        "description", "itunes:summary" -> if (desc.isEmpty()) desc = text()
                    }
                }
            } else if (ev == XmlPullParser.END_TAG) {
                val name = p.name.lowercase()
                if (name == "image") inChannelImage = false
                if ((name == "item" || name == "entry") && inItem) {
                    inItem = false
                    if (iUrl.isNotEmpty()) {
                        val guid = iGuid.ifEmpty { iUrl }
                        episodes += Episode(
                            id = stableId(feedUrl, guid),
                            feedUrl = feedUrl,
                            title = iTitle.ifEmpty { "Avsnitt utan namn" },
                            dateMs = iDate,
                            audioUrl = iUrl,
                            audioType = iType,
                            durationSec = iDur,
                            notes = listOf(iContent, iDesc, iSummary).maxByOrNull { it.length } ?: "",
                            imageUrl = iImage,
                            chaptersUrl = iChapters,
                            season = iSeason,
                            number = iNum,
                        )
                    }
                }
            }
            ev = runCatching { p.next() }.getOrElse { XmlPullParser.END_DOCUMENT }
        }
        val pod = Podcast(feedUrl, title.ifEmpty { "Podd utan namn" }, author, image, desc)
        return pod to episodes.sortedByDescending { it.dateMs }
    }

    /** Podcasting 2.0 chapters file. */
    fun parseChapters(json: String): List<Chapter> {
        val arr = JSONObject(json).optJSONArray("chapters") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            if (o.has("toc") && !o.optBoolean("toc", true)) return@mapNotNull null
            Chapter(
                (o.optDouble("startTime", 0.0) * 1000).toLong(),
                o.optString("title").ifEmpty { "Kapitel ${i + 1}" },
                o.optString("url").takeIf { it.isNotEmpty() },
            )
        }.sortedBy { it.startMs }
    }
}

/** Apple's podcast directory: free, no account. */
object PodcastSearch {
    fun search(term: String): List<SearchHit> {
        val json = Http.get("https://itunes.apple.com/search?media=podcast&limit=30&term=" + URLEncoder.encode(term.trim(), "UTF-8"))
        val arr = JSONObject(json).optJSONArray("results") ?: JSONArray()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val feed = o.optString("feedUrl").takeIf { it.isNotEmpty() } ?: return@mapNotNull null
            SearchHit(
                o.optString("collectionName"), o.optString("artistName"), feed,
                o.optString("artworkUrl600").ifEmpty { o.optString("artworkUrl100") },
            )
        }
    }
}
