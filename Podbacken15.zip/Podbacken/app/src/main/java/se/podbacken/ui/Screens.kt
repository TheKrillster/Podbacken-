package se.podbacken.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.fromHtml
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import se.podbacken.Chapter
import se.podbacken.MainViewModel
import se.podbacken.PodcastSearch
import se.podbacken.Screen
import se.podbacken.SearchHit

@Composable
fun PodcastScreen(vm: MainViewModel, feedUrl: String) {
    val c = LocalSkiv.current
    val p = vm.podcast(feedUrl) ?: run { TopBar("Podden finns inte längre", vm); return }
    val oldest = vm.sortOldest(feedUrl)
    val all = vm.episodes[feedUrl].orEmpty()
    val eps = if (oldest) all.sortedBy { it.dateMs } else all.sortedByDescending { it.dateMs }
    var more by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            TopBar("", vm) {
                PressButton(onClick = { vm.openPodSettings(feedUrl) }, size = 44.dp) { Glyph(Ic.Settings, c.ink, Modifier.size(23.dp)) }
            }
        }
        item {
            Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.Top) {
                Cover(p.imageUrl, 116.dp, corner = 8.dp)
                Column(Modifier.padding(start = 14.dp)) {
                    Text(p.title, fontSize = 22.sp, lineHeight = 26.sp, fontWeight = FontWeight.ExtraBold, color = c.ink)
                    if (p.author.isNotEmpty()) Text(p.author, modifier = Modifier.padding(top = 4.dp), fontSize = 13.5.sp, color = c.inkSoft)
                    Text("${eps.size} avsnitt", modifier = Modifier.padding(top = 4.dp), fontSize = 12.5.sp, color = c.inkSoft)
                }
            }
        }
        if (p.description.isNotBlank()) item {
            Text(
                AnnotatedString.fromHtml(notesHtml(p.description), linkStyles = TextLinkStyles(SpanStyle(color = c.sticker, textDecoration = TextDecoration.Underline))),
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp).clickable { more = !more },
                fontSize = 14.sp, lineHeight = 20.sp, color = c.ink, maxLines = if (more) Int.MAX_VALUE else 3, overflow = TextOverflow.Ellipsis,
            )
        }
        item {
            val active = listOfNotNull(
                if (feedUrl in vm.notifyFeeds) "aviseringar" else null,
                if (feedUrl in vm.autoFeeds) "nedladdning" else null,
                if (vm.skipStartOf(feedUrl) > 0 || vm.skipEndOf(feedUrl) > 0) "hoppar över" else null,
            )
            if (active.isNotEmpty()) {
                Text(
                    "På: " + active.joinToString(", "),
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp).clickable { vm.openPodSettings(feedUrl) },
                    fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = c.sticker, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(end = 16.dp), verticalAlignment = Alignment.Bottom) {
                SectionTitle("AVSNITT", Modifier.weight(1f))
                Chip(if (oldest) "Äldst först ↑" else "Nyast först ↓") { vm.pickSortOldest(feedUrl, !oldest) }
            }
        }
        items(eps, key = { it.id }) { e -> EpisodeRow(vm, e, showPodcast = false) { vm.open(Screen.EpisodeView(e.id)) } }
    }
}

/** Slides up from the bottom when you tap a podcast's cog wheel. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PodSettingsSheet(vm: MainViewModel, feedUrl: String) {
    val c = LocalSkiv.current
    val p = vm.podcast(feedUrl) ?: return
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(onDismissRequest = { vm.closePodSettings() }, sheetState = state, containerColor = c.panel) {
        Row(Modifier.padding(horizontal = 20.dp).padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Cover(p.imageUrl, 56.dp, corner = 10.dp)
            Column(Modifier.padding(start = 14.dp)) {
                Text("Inställningar", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = c.inkSoft)
                Text(p.title, fontSize = 19.sp, lineHeight = 23.sp, fontWeight = FontWeight.ExtraBold, color = c.ink, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        PodSettings(vm, feedUrl)
        Spacer(Modifier.height(20.dp))
    }
}

/** The podcast's own settings: notices, automatic downloads and skipping intros and outros. */
@Composable
private fun PodSettings(vm: MainViewModel, feedUrl: String) {
    val c = LocalSkiv.current
    var confirm by remember { mutableStateOf(false) }
    Column(
        Modifier
            .padding(horizontal = 20.dp, vertical = 6.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(c.chip)
            .padding(vertical = 6.dp),
    ) {
        SettingSwitch("Avisera nya avsnitt", "Ett meddelande när ett nytt avsnitt kommer ut.", feedUrl in vm.notifyFeeds) { vm.setNotify(feedUrl, it) }
        SettingSwitch("Ladda ner nya automatiskt", "Bara på wifi. Avsnitt du lyssnat klart raderas.", feedUrl in vm.autoFeeds) { vm.setAuto(feedUrl, it) }
        SettingStepper("Hoppa över början", "Till exempel intro eller reklam i början.", vm.skipStartOf(feedUrl)) { vm.changeSkipStart(feedUrl, it) }
        SettingStepper("Hoppa över slutet", "Avsnittet räknas som lyssnat och nästa i kön startar.", vm.skipEndOf(feedUrl)) { vm.changeSkipEnd(feedUrl, it) }
        Box(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Chip(if (confirm) "Tryck igen för att avsluta" else "Avsluta prenumeration", on = confirm) {
                if (confirm) {
                    vm.unsubscribe(feedUrl)
                    if (!vm.back()) vm.home(1)
                } else {
                    confirm = true
                }
            }
        }
    }
}

@Composable
private fun SettingSwitch(title: String, hint: String, on: Boolean, onChange: (Boolean) -> Unit) {
    val c = LocalSkiv.current
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!on) }.padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 10.dp)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = c.ink)
            Text(hint, fontSize = 12.5.sp, lineHeight = 16.sp, color = c.inkSoft)
        }
        Switch(
            checked = on,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = c.stickerInk,
                checkedTrackColor = c.sticker,
                uncheckedThumbColor = c.inkSoft,
                uncheckedTrackColor = c.panel,
                uncheckedBorderColor = c.inkSoft,
            ),
        )
    }
}

private fun fmtSkip(s: Int): String = when {
    s <= 0 -> "Av"
    s < 60 -> "$s s"
    else -> "%d:%02d".format(s / 60, s % 60)
}

@Composable
private fun SettingStepper(title: String, hint: String, seconds: Int, onChange: (Int) -> Unit) {
    val c = LocalSkiv.current
    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = c.ink)
            Text(hint, fontSize = 12.5.sp, lineHeight = 16.sp, color = c.inkSoft)
        }
        PressButton(onClick = { onChange((seconds - if (seconds > 60) 15 else 5).coerceAtLeast(0)) }, size = 38.dp, background = c.panel) {
            Text("−", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = c.ink)
        }
        Text(
            fmtSkip(seconds), modifier = Modifier.width(56.dp), textAlign = TextAlign.Center,
            fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = if (seconds > 0) c.sticker else c.inkSoft,
        )
        PressButton(onClick = { onChange((seconds + if (seconds >= 60) 15 else 5).coerceAtMost(600)) }, size = 38.dp, background = c.panel) {
            Text("+", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = c.ink)
        }
    }
}

@Composable
fun EpisodeScreen(vm: MainViewModel, id: String) {
    val c = LocalSkiv.current
    val e = vm.episode(id) ?: run { TopBar("Avsnittet finns inte längre", vm); return }
    val pod = vm.podcast(e.feedUrl)
    val chapters by produceState<List<Chapter>>(emptyList(), e.id) { value = vm.chapters(e) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("", vm)
        Column(Modifier.padding(horizontal = 20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { pod?.let { vm.open(Screen.PodcastView(it.feedUrl)) } }) {
                Cover(e.imageUrl.ifEmpty { pod?.imageUrl }, 88.dp, corner = 8.dp)
                Text(pod?.title ?: "", modifier = Modifier.padding(start = 12.dp), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = c.inkSoft)
            }
            Text(e.title, modifier = Modifier.padding(top = 14.dp), fontSize = 24.sp, lineHeight = 29.sp, fontWeight = FontWeight.ExtraBold, color = c.ink)
            val meta = listOfNotNull(
                fmtDate(e.dateMs).ifEmpty { null },
                fmtDur(e.durationSec).ifEmpty { null },
                if (e.season > 0 || e.number > 0) listOfNotNull(if (e.season > 0) "Säsong ${e.season}" else null, if (e.number > 0) "avsnitt ${e.number}" else null).joinToString(", ") else null,
            ).joinToString(" · ")
            Text(meta, modifier = Modifier.padding(top = 6.dp), fontSize = 13.sp, color = c.inkSoft)
            Row(Modifier.padding(top = 14.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(if (e.id == vm.currentId && vm.isPlaying) "Spelas nu" else "Spela", on = true) { vm.play(e); vm.open(Screen.Player) }
                Chip("Spela härnäst") { vm.playNext(e) }
                Chip("Lägg i kön") { vm.addToQueue(e) }
                if (vm.isDownloaded(e)) Chip("Ta bort nedladdning") { vm.removeDownload(e) }
                else Chip("Ladda ner") { vm.download(e) }
            }
        }
        if (chapters.isNotEmpty()) {
            SectionTitle("KAPITEL")
            ChapterList(chapters) { ms -> vm.play(e); vm.seek(ms) }
        }
        SectionTitle("OM AVSNITTET")
        Notes(e.notes)
        Box(Modifier.padding(24.dp))
    }
}

@Composable
fun Notes(raw: String) {
    val c = LocalSkiv.current
    if (raw.isBlank()) {
        Text("Det finns ingen beskrivning till avsnittet.", modifier = Modifier.padding(horizontal = 20.dp), fontSize = 14.sp, color = c.inkSoft)
        return
    }
    val text = remember(raw, c.sticker) {
        AnnotatedString.fromHtml(notesHtml(raw), linkStyles = TextLinkStyles(SpanStyle(color = c.sticker, textDecoration = TextDecoration.Underline)))
    }
    Text(text, modifier = Modifier.padding(horizontal = 20.dp), fontSize = 15.sp, lineHeight = 22.sp, color = c.ink)
}

@Composable
fun ChapterList(chapters: List<Chapter>, currentMs: Long? = null, onPick: (Long) -> Unit) {
    val c = LocalSkiv.current
    val active = currentMs?.let { ms -> chapters.indexOfLast { it.startMs <= ms } } ?: -1
    chapters.forEachIndexed { i, ch ->
        Row(Modifier.fillMaxWidth().clickable { onPick(ch.startMs) }.padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(fmtTime(ch.startMs), modifier = Modifier.padding(end = 12.dp), fontSize = 12.5.sp, color = if (i == active) c.sticker else c.inkSoft)
            Text(
                ch.title, modifier = Modifier.weight(1f), fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                fontWeight = if (i == active) FontWeight.SemiBold else FontWeight.Normal, color = if (i == active) c.sticker else c.ink,
            )
        }
    }
}

@Composable
fun SearchScreen(vm: MainViewModel) {
    val c = LocalSkiv.current
    val ctx = LocalContext.current
    val focus = LocalFocusManager.current
    val scope = rememberCoroutineScope()
    var term by remember { mutableStateOf("") }
    var rss by remember { mutableStateOf("") }
    var hits by remember { mutableStateOf<List<SearchHit>?>(emptyList()) }
    var busy by remember { mutableStateOf<String?>(null) }
    val fieldColors = OutlinedTextFieldDefaults.colors(focusedBorderColor = c.sticker, focusedLabelColor = c.sticker, cursorColor = c.sticker)

    fun search() {
        focus.clearFocus()
        if (term.isBlank()) return
        hits = null
        scope.launch {
            hits = withContext(Dispatchers.IO) { runCatching { PodcastSearch.search(term) }.getOrDefault(emptyList()) }
        }
    }
    fun add(url: String) {
        busy = url
        scope.launch {
            val err = vm.subscribe(url)
            busy = null
            Toast.makeText(ctx, err ?: "Podden är tillagd", if (err == null) Toast.LENGTH_SHORT else Toast.LENGTH_LONG).show()
            if (err == null && url == rss) rss = ""
        }
    }

    LazyColumn(Modifier.fillMaxSize()) {
        item { TopBar("Lägg till podd", vm) }
        item {
            Row(Modifier.padding(horizontal = 20.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    term, { term = it }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("Sök podd") },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { search() }),
                    colors = fieldColors,
                )
                Chip("Sök", on = true, modifier = Modifier.padding(start = 10.dp)) { search() }
            }
        }
        item { SectionTitle("ELLER KLISTRA IN EN RSS-LÄNK") }
        item {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Text(
                    "Till exempel din privata länk från Patreon, Supercast eller Memberful. Den sparas bara på telefonen.",
                    fontSize = 13.sp, color = c.inkSoft, modifier = Modifier.padding(bottom = 6.dp),
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        rss, { rss = it }, modifier = Modifier.weight(1f), singleLine = true, label = { Text("https://…") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Done),
                        keyboardActions = KeyboardActions(onDone = { focus.clearFocus(); if (rss.isNotBlank()) add(rss) }),
                        colors = fieldColors,
                    )
                    Chip(if (busy == rss && rss.isNotEmpty()) "Läser…" else "Lägg till", on = true, modifier = Modifier.padding(start = 10.dp)) {
                        focus.clearFocus()
                        if (rss.isNotBlank() && busy == null) add(rss)
                    }
                }
            }
        }
        val list = hits
        item { SectionTitle(if (list == null) "SÖKER…" else if (list.isEmpty()) "" else "TRÄFFAR") }
        if (list != null) items(list, key = { it.feedUrl }) { h ->
            val subscribed = vm.podcasts.any { it.feedUrl == h.feedUrl }
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Cover(h.imageUrl, 56.dp)
                Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                    Text(h.title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = c.ink, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(h.author, fontSize = 12.5.sp, color = c.inkSoft, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                when {
                    subscribed -> Text("Tillagd", fontSize = 13.sp, color = c.inkSoft)
                    busy == h.feedUrl -> Text("Hämtar…", fontSize = 13.sp, color = c.inkSoft)
                    else -> Chip("Lägg till") { if (busy == null) add(h.feedUrl) }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val c = LocalSkiv.current
    val dark = c.panel == DarkSkiv.panel
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        TopBar("Inställningar", vm)
        SectionTitle("FÄRG")
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Accents.forEachIndexed { i, a ->
                val on = i == ThemePrefs.accent
                Column(Modifier.clip(RoundedCornerShape(10.dp)).clickable { ThemePrefs.pickAccent(i) }.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.size(40.dp).border(if (on) 2.dp else 0.dp, if (on) c.ink else Color.Transparent, CircleShape)
                            .padding(4.dp).clip(CircleShape).background(if (dark) a.dark else a.light),
                    )
                    Text(a.name, modifier = Modifier.padding(top = 4.dp), fontSize = 11.5.sp, color = if (on) c.ink else c.inkSoft)
                }
            }
        }
        SectionTitle("LJUST ELLER MÖRKT")
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(ThemePrefs.SYSTEM to "Som telefonen", ThemePrefs.LIGHT to "Ljust", ThemePrefs.DARK to "Mörkt").forEach { (m, label) ->
                Chip(label, on = ThemePrefs.mode == m) { ThemePrefs.pickMode(m) }
            }
        }
        SectionTitle("NEDLADDNING OCH AVISERINGAR")
        Text(
            "Slå på \"Ladda ner nya automatiskt\" eller \"Avisera nya avsnitt\" inne på en podd. Appen kollar efter nya avsnitt ungefär var fjärde timme. " +
                "Nedladdningar görs bara på wifi, och avsnitt du lyssnat klart på raderas automatiskt.",
            modifier = Modifier.padding(horizontal = 20.dp), fontSize = 14.sp, lineHeight = 20.sp, color = c.inkSoft,
        )
    }
}
