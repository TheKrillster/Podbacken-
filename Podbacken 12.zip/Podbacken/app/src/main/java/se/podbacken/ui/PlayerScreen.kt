package se.podbacken.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.first
import se.podbacken.Chapter
import se.podbacken.MainViewModel
import se.podbacken.Screen
import kotlin.math.sqrt

private val Speeds = listOf(0.8f, 1f, 1.2f, 1.5f, 1.8f, 2f)
private val Sleeps = listOf<Int?>(null, 15, 30, 45, 60, -1)

/** Full-screen player: the cassette on top, notes/chapters/queue below, buttons fixed at the bottom. */
@Composable
fun PlayerScreen(vm: MainViewModel) {
    val c = LocalSkiv.current
    val e = vm.current
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().background(c.panel).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            PressButton(onClick = { if (!vm.back()) vm.home(0) }, size = 48.dp) { Glyph(Ic.Down, c.ink, Modifier.size(26.dp)) }
            Text("Spelas nu", fontSize = 14.sp, color = c.inkSoft)
        }
        if (e == null) {
            Text("Inget avsnitt spelas. Välj ett i listan.", modifier = Modifier.padding(24.dp), fontSize = 17.sp, color = c.ink)
            return@Column
        }
        val pod = vm.podcast(e.feedUrl)
        val chapters by produceState<List<Chapter>>(emptyList(), e.id) { value = vm.chapters(e) }
        val progress = if (vm.durationMs > 0) (vm.positionMs.toFloat() / vm.durationMs).coerceIn(0f, 1f) else 0f

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Cassette(
                title = e.title, show = pod?.title ?: "", progress = progress, playing = vm.isPlaying,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp).fillMaxWidth(),
            )
            val tabs = buildList {
                add("Om avsnittet")
                if (chapters.isNotEmpty()) add("Kapitel")
                add(if (vm.queue.isEmpty()) "Kö" else "Kö · ${vm.queue.size}")
            }
            if (tab >= tabs.size) tab = 0
            Row(Modifier.padding(horizontal = 16.dp).padding(top = 12.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                tabs.forEachIndexed { i, t -> Chip(t, on = i == tab) { tab = i } }
            }
            when (tabs[tab]) {
                "Om avsnittet" -> Notes(e.notes)
                "Kapitel" -> ChapterList(chapters, vm.positionMs) { vm.seek(it) }
                else -> {
                    if (vm.queue.isEmpty()) {
                        Text("Kön är tom.", modifier = Modifier.padding(16.dp), fontSize = 15.sp, color = c.inkSoft)
                    }
                    vm.queue.forEach { id ->
                        vm.episode(id)?.let { q ->
                            EpisodeRow(vm, q, showPodcast = true, leftLabel = "Ta bort ur kön", leftAction = { vm.removeFromQueue(id) }) {
                                vm.open(Screen.EpisodeView(id))
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        Column(Modifier.fillMaxWidth().shadow(10.dp).background(c.panel).navigationBarsPadding().padding(top = 8.dp)) {
            Column(Modifier.padding(horizontal = 20.dp)) {
                Text(e.title, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = c.ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(pod?.title ?: "", fontSize = 13.sp, color = c.inkSoft, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            SeekBar(vm.positionMs, vm.durationMs, onSeek = { vm.seek(it) }, modifier = Modifier.padding(horizontal = 20.dp).padding(top = 4.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                val si = Speeds.indexOfFirst { kotlin.math.abs(it - vm.speed) < 0.01f }.coerceAtLeast(0)
                Chip(("%.1f×".format(vm.speed)).replace('.', ',')) { vm.changeSpeed(Speeds[(si + 1) % Speeds.size]) }
                PressButton(onClick = { vm.skip(-15) }, size = 52.dp) { SkipGlyph(back = true) }
                PressButton(onClick = { vm.toggle() }, size = 60.dp, background = c.sticker, modifier = Modifier.shadow(8.dp, CircleShape)) {
                    Crossfade(vm.isPlaying, label = "playpause") { p -> Glyph(if (p) Ic.Pause else Ic.Play, c.stickerInk, Modifier.size(28.dp)) }
                }
                PressButton(onClick = { vm.skip(30) }, size = 52.dp) { SkipGlyph(back = false) }
                val sleepLabel = when (val s = vm.sleepLeftMin) {
                    null -> "Sov"
                    -1 -> "Slutet"
                    else -> "$s min"
                }
                Chip(sleepLabel, on = vm.sleepLeftMin != null) {
                    val cur = Sleeps.indexOf(vm.sleepLeftMin.let { if (it != null && it > 0) Sleeps.filterNotNull().filter { s -> s > 0 }.firstOrNull { s -> s >= it } else it })
                    vm.setSleep(Sleeps[(cur + 1).coerceAtLeast(1) % Sleeps.size])
                }
            }
            Spacer(Modifier.height(4.dp))
        }
    }
}

@Composable
private fun SkipGlyph(back: Boolean) {
    val c = LocalSkiv.current
    Box(contentAlignment = Alignment.Center) {
        Glyph(if (back) Ic.ArcBack else Ic.ArcFwd, c.ink, Modifier.size(34.dp))
        Text(if (back) "15" else "30", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = c.ink, modifier = Modifier.padding(top = 2.dp))
    }
}

/** Thin timeline: tap or drag anywhere on it. */
@Composable
private fun SeekBar(positionMs: Long, durationMs: Long, onSeek: (Long) -> Unit, modifier: Modifier) {
    val c = LocalSkiv.current
    var drag by remember { mutableStateOf<Float?>(null) }
    val dur = durationMs.coerceAtLeast(1L)
    val frac = drag ?: (positionMs.toFloat() / dur).coerceIn(0f, 1f)
    Column(modifier.fillMaxWidth()) {
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(22.dp)
                .pointerInput(dur) { detectTapGestures { o -> onSeek(((o.x / size.width).coerceIn(0f, 1f) * dur).toLong()) } }
                .pointerInput(dur) {
                    detectHorizontalDragGestures(
                        onDragStart = { o -> drag = (o.x / size.width).coerceIn(0f, 1f) },
                        onDragEnd = { drag?.let { onSeek((it * dur).toLong()) }; drag = null },
                        onDragCancel = { drag = null },
                    ) { change, _ ->
                        change.consume()
                        drag = (change.position.x / size.width).coerceIn(0f, 1f)
                    }
                },
        ) {
            val h = if (drag != null) 6.dp.toPx() else 4.dp.toPx()
            val y = size.height / 2f - h / 2f
            drawRoundRect(c.line, Offset(0f, y), Size(size.width, h), CornerRadius(h))
            drawRoundRect(if (drag != null) c.sticker else c.ink, Offset(0f, y), Size(size.width * frac, h), CornerRadius(h))
            if (drag != null) drawCircle(c.sticker, 8.dp.toPx(), Offset(size.width * frac, size.height / 2f))
        }
        Row(Modifier.fillMaxWidth()) {
            Text(fmtTime((frac * dur).toLong()), fontSize = 11.sp, color = c.inkSoft, modifier = Modifier.weight(1f))
            Text("-" + fmtTime(((1f - frac) * dur).toLong()), fontSize = 11.sp, color = c.inkSoft)
        }
    }
}

/**
 * A cassette tape. The tape moves from the left reel to the right one as the episode plays,
 * and each hub turns faster the less tape it holds, like the real thing.
 */
@Composable
private fun Cassette(title: String, show: String, progress: Float, playing: Boolean, modifier: Modifier) {
    val c = LocalSkiv.current
    val playingState = rememberUpdatedState(playing)
    val progressState = rememberUpdatedState(progress)
    var angleL by remember { mutableFloatStateOf(0f) }
    var angleR by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        var run = 0f
        while (true) {
            if (!playingState.value && run < 0.02f) {
                run = 0f
                last = 0L
                snapshotFlow { playingState.value }.first { it }
            }
            withFrameNanos { now ->
                if (last != 0L) {
                    val dt = ((now - last) / 1e9f).coerceAtMost(0.1f)
                    run += ((if (playingState.value) 1f else 0f) - run) * (dt * 4f).coerceAtMost(1f)
                    val p = progressState.value
                    val rl = 0.35f + 0.65f * sqrt(1f - p)
                    val rr = 0.35f + 0.65f * sqrt(p)
                    // Constant tape speed: smaller reel turns faster.
                    angleL = (angleL + run * dt * 70f / rl) % 360f
                    angleR = (angleR + run * dt * 70f / rr) % 360f
                }
                last = now
            }
        }
    }
    val accent = c.sticker
    BoxWithConstraints(modifier.aspectRatio(1.6f)) {
        val bw = maxWidth
        Canvas(Modifier.fillMaxSize().shadow(18.dp, androidx.compose.foundation.shape.RoundedCornerShape(16.dp))) {
            val w = size.width
            val h = size.height
            val shell = Color(0xFF2A2D31)

            // Shell: dark plastic, lit from above, with a bevelled edge.
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0xFF43474D), shell, Color(0xFF1B1D20))),
                size = size, cornerRadius = CornerRadius(w * 0.045f),
            )
            drawRoundRect(
                Color.White.copy(alpha = 0.12f), Offset(w * 0.005f, w * 0.005f), Size(w * 0.99f, h - w * 0.01f),
                CornerRadius(w * 0.042f), style = Stroke(w * 0.004f),
            )
            // Write-protect tabs along the top edge.
            drawRect(Color(0xFF15171A), Offset(w * 0.11f, 0f), Size(w * 0.05f, h * 0.035f))
            drawRect(Color(0xFF15171A), Offset(w * 0.84f, 0f), Size(w * 0.05f, h * 0.035f))
            // Corner screws.
            listOf(Offset(w * 0.035f, h * 0.065f), Offset(w * 0.965f, h * 0.065f), Offset(w * 0.035f, h * 0.935f), Offset(w * 0.965f, h * 0.935f))
                .forEach { screw(it, w * 0.016f) }

            // Paper label.
            val lt = Offset(w * 0.07f, h * 0.075f)
            val ls = Size(w * 0.86f, h * 0.64f)
            drawRoundRect(Color.Black.copy(alpha = 0.35f), lt + Offset(0f, w * 0.005f), ls, CornerRadius(w * 0.022f))
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0xFFF8F3E7), Color(0xFFE7DEC8)), startY = lt.y, endY = lt.y + ls.height),
                lt, ls, CornerRadius(w * 0.022f),
            )
            // Writing line under the title.
            drawLine(
                Color(0x26000000), Offset(lt.x + ls.width * 0.13f, lt.y + ls.height * 0.42f),
                Offset(lt.x + ls.width * 0.96f, lt.y + ls.height * 0.42f), w * 0.0025f,
            )
            // Printed colour bands around the window.
            drawRect(lerp(accent, Color.White, 0.45f), Offset(lt.x, lt.y + ls.height * 0.47f), Size(ls.width, ls.height * 0.03f))
            drawRect(accent, Offset(lt.x, lt.y + ls.height * 0.50f), Size(ls.width, ls.height * 0.32f))
            drawRect(lerp(accent, Color.Black, 0.3f), Offset(lt.x, lt.y + ls.height * 0.82f), Size(ls.width, ls.height * 0.05f))

            // Window of smoked plastic.
            val wt = Offset(w * 0.23f, h * 0.37f)
            val ws = Size(w * 0.54f, h * 0.23f)
            val rim = w * 0.012f
            drawRoundRect(Color(0xFF15171A), wt - Offset(rim, rim), Size(ws.width + rim * 2f, ws.height + rim * 2f), CornerRadius(ws.height * 0.5f + rim))
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0xFF282C31), Color(0xFF0F1113)), startY = wt.y, endY = wt.y + ws.height),
                wt, ws, CornerRadius(ws.height * 0.5f),
            )
            val cl = Offset(w * 0.355f, wt.y + ws.height / 2f)
            val cr = Offset(w * 0.645f, wt.y + ws.height / 2f)
            val rMin = w * 0.05f
            val rMax = w * 0.13f
            val rl = rMin + (rMax - rMin) * sqrt(1f - progress)
            val rr = rMin + (rMax - rMin) * sqrt(progress)
            clipRect(wt.x, wt.y, wt.x + ws.width, wt.y + ws.height) {
                tapePack(cl, rl, rMin)
                tapePack(cr, rr, rMin)
                hub(cl, rMin * 0.85f, angleL)
                hub(cr, rMin * 0.85f, angleR)
                // Glare across the plastic.
                drawPath(Path().apply {
                    moveTo(wt.x + ws.width * 0.12f, wt.y)
                    lineTo(wt.x + ws.width * 0.30f, wt.y)
                    lineTo(wt.x + ws.width * 0.20f, wt.y + ws.height)
                    lineTo(wt.x + ws.width * 0.02f, wt.y + ws.height)
                    close()
                }, Color.White.copy(alpha = 0.07f))
            }
            drawRoundRect(Color.White.copy(alpha = 0.10f), wt, ws, CornerRadius(ws.height * 0.5f), style = Stroke(w * 0.003f))

            // Bottom bridge where the tape runs past the heads.
            val bridge = Path().apply {
                moveTo(w * 0.17f, h)
                lineTo(w * 0.23f, h * 0.77f)
                lineTo(w * 0.77f, h * 0.77f)
                lineTo(w * 0.83f, h)
                close()
            }
            drawPath(bridge, Brush.verticalGradient(listOf(Color(0xFF24272B), Color(0xFF141618)), startY = h * 0.77f, endY = h))
            drawPath(bridge, Color.White.copy(alpha = 0.08f), style = Stroke(w * 0.003f))
            listOf(0.30f, 0.39f, 0.61f, 0.70f).forEach { fx ->
                drawRoundRect(Color(0xFF0A0B0C), Offset(w * fx - w * 0.018f, h * 0.885f), Size(w * 0.036f, h * 0.05f), CornerRadius(w * 0.006f))
            }
            drawRoundRect(Color(0xFF0A0B0C), Offset(w * 0.455f, h * 0.875f), Size(w * 0.09f, h * 0.07f), CornerRadius(w * 0.008f))
            // Felt pressure pad, then the tape between two guide rollers.
            drawRect(Color(0xFFB89A6A), Offset(w * 0.475f, h * 0.85f), Size(w * 0.05f, h * 0.022f))
            val ty = h * 0.865f
            drawLine(Color(0xFF5E412E), Offset(w * 0.12f, ty), Offset(w * 0.88f, ty), w * 0.008f)
            listOf(0.12f, 0.88f).forEach { fx ->
                drawCircle(Color(0xFFDAD7CD), w * 0.017f, Offset(w * fx, ty))
                drawCircle(Color(0xFF6B6B66), w * 0.006f, Offset(w * fx, ty))
            }
        }
        // Title and show, written on the label.
        Row(
            Modifier.fillMaxWidth().padding(start = bw * 0.095f, end = bw * 0.09f, top = bw * 0.07f),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(bw * 0.07f).clip(CircleShape).background(accent), contentAlignment = Alignment.Center) {
                Text("A", fontSize = 12.sp, fontWeight = FontWeight.Black, color = c.stickerInk)
            }
            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                Text(show.uppercase(), fontSize = 10.sp, letterSpacing = 0.12.em, color = Color(0xFF6A665C), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(title, fontSize = 14.sp, lineHeight = 17.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1C1C18), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Text(
            "C90", modifier = Modifier.align(Alignment.TopStart).padding(start = bw * 0.095f, top = bw * 0.295f),
            fontSize = 12.sp, fontWeight = FontWeight.Black, color = c.stickerInk,
        )
        Text(
            "STEREO", modifier = Modifier.align(Alignment.TopEnd).padding(end = bw * 0.09f, top = bw * 0.3f),
            fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.14.em, color = c.stickerInk,
        )
    }
}

private fun DrawScope.screw(at: Offset, r: Float) {
    drawCircle(Brush.radialGradient(listOf(Color(0xFFC3C8CD), Color(0xFF6A6F74)), center = at, radius = r), r, at)
    drawLine(Color(0xFF2E3134), Offset(at.x - r * 0.6f, at.y - r * 0.2f), Offset(at.x + r * 0.6f, at.y + r * 0.2f), r * 0.3f)
}

/** Wound tape: dark brown with faint rings. */
private fun DrawScope.tapePack(at: Offset, r: Float, core: Float) {
    drawCircle(Brush.radialGradient(listOf(Color(0xFF6E4C35), Color(0xFF4B3324), Color(0xFF3A271B)), center = at, radius = r), r, at)
    for (i in 1..4) {
        val k = core + (r - core) * i / 5f
        if (k > core + 1f) drawCircle(Color.Black.copy(alpha = 0.10f), k, at, style = Stroke(1f))
    }
    drawCircle(Color.White.copy(alpha = 0.10f), r, at, style = Stroke(1.2f))
}

private fun DrawScope.hub(at: Offset, r: Float, angle: Float) {
    drawCircle(Color(0xFFF1EFE8), r, at)
    drawCircle(Color(0xFFCFCBC0), r, at, style = Stroke(r * 0.08f))
    drawCircle(Color(0xFF1B1C1E), r * 0.58f, at)
    rotate(angle, at) {
        for (k in 0 until 6) {
            rotate(k * 60f, at) {
                drawRect(Color(0xFFF1EFE8), Offset(at.x - r * 0.09f, at.y - r * 0.60f), Size(r * 0.18f, r * 0.26f))
            }
        }
        for (k in 0 until 3) {
            rotate(k * 120f + 30f, at) {
                drawCircle(Color(0xFF9A968C), r * 0.08f, Offset(at.x, at.y - r * 0.80f))
            }
        }
    }
}
