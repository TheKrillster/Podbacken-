package se.podbacken

import android.content.Context
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

/** True while the app's screen (and its view model) is alive; then the app handles skips and progress itself. */
object PlaybackHub {
    @Volatile
    var appActive = false
}

/** The saved podcasts, episodes and progress, read from the phone for the car and the widget. */
class Library(val podcasts: List<Podcast>, val episodes: Map<String, List<Episode>>, val state: Store.State) {
    val byId: Map<String, Episode> = episodes.values.flatten().associateBy { it.id }

    fun podcast(feedUrl: String): Podcast? = podcasts.firstOrNull { it.feedUrl == feedUrl }

    fun latest(): List<Episode> = byId.values.sortedByDescending { it.dateMs }.take(60)

    fun episodesOf(ctx: Context, feedUrl: String): List<Episode> {
        val list = episodes[feedUrl].orEmpty()
        val sorted = if (sortOldest(ctx, feedUrl)) list.sortedBy { it.dateMs } else list.sortedByDescending { it.dateMs }
        return sorted.take(300)
    }

    /** Where to start: where you left off, but never inside the skipped intro. */
    fun startPos(ctx: Context, e: Episode): Long {
        val skip = skipStartOf(ctx, e.feedUrl) * 1000L
        if (e.id in state.played) return skip
        val p = state.positions[e.id] ?: 0L
        val resume = if (e.durationSec > 0 && p > e.durationSec * 1000 - 5_000) 0L else p
        return maxOf(resume, skip)
    }

    fun playable(ctx: Context, e: Episode): MediaItem {
        val pod = podcast(e.feedUrl)
        val art = e.imageUrl.ifEmpty { pod?.imageUrl ?: "" }
        val file = Downloads.file(ctx, e)
        val md = MediaMetadata.Builder()
            .setTitle(e.title)
            .setArtist(pod?.title)
            .setAlbumTitle(pod?.title)
            .setSubtitle(pod?.title)
            .setIsBrowsable(false)
            .setIsPlayable(true)
            .setMediaType(MediaMetadata.MEDIA_TYPE_PODCAST_EPISODE)
        if (art.isNotEmpty()) md.setArtworkUri(Uri.parse(art))
        return MediaItem.Builder()
            .setMediaId(e.id)
            .setUri(if (file.exists()) Uri.fromFile(file) else Uri.parse(e.audioUrl))
            .setMediaMetadata(md.build())
            .build()
    }

    companion object {
        fun load(ctx: Context): Library {
            val pods = Store.loadPodcasts(ctx)
            return Library(pods, pods.associate { it.feedUrl to Store.loadEpisodes(ctx, it.feedUrl) }, Store.loadState(ctx))
        }

        private fun prefs(ctx: Context) = ctx.getSharedPreferences("podbacken", Context.MODE_PRIVATE)
        fun sortOldest(ctx: Context, feedUrl: String): Boolean = prefs(ctx).getBoolean("sortOld:" + stableId(feedUrl), false)
        fun skipStartOf(ctx: Context, feedUrl: String): Int = prefs(ctx).getInt("skipStart:" + stableId(feedUrl), 0)
        fun skipEndOf(ctx: Context, feedUrl: String): Int = prefs(ctx).getInt("skipEnd:" + stableId(feedUrl), 0)
    }
}
