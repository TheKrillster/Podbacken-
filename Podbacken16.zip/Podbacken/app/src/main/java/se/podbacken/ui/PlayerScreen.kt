package se.podbacken.ui

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.widthIn
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.drawscope.clipPath
import kotlin.random.Random
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import se.podbacken.Episode
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.flow.first
import se.podbacken.Chapter
import se.podbacken.MainViewModel
import se.podbacken.Screen
import kotlin.math.sqrt

private val Speeds = listOf(0.8f, 1f, 1.2f, 1.5f, 1.8f, 2f)
private val Sleeps = listOf<Int?>(null, 15, 30, 45, 60, -1)

/** "Now playing": the cassette, the controls right under it, then notes, chapters and the queue. */
@Composable
fun PlayerScreen(vm: MainViewModel) {
    val c = LocalSkiv.current
    val e = vm.current
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().background(c.panel).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            PressButton(onClick = { if (!vm.back()) vm.home(0) }, size = 48.dp) { Glyph(Ic.Down, c.ink, Modifier.size(26.dp)) }
            Text("Spelas nu", modifier = Modifier.weight(1f), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = c.inkSoft)
        }
        if (e == null) {
            Text("Inget avsnitt spelas. Välj ett i listan.", modifier = Modifier.padding(28.dp), fontSize = 17.sp, color = c.ink)
            return@Column
        }
        val pod = vm.podcast(e.feedUrl)
        val chapters by produceState<List<Chapter>>(emptyList(), e.id) { value = vm.chapters(e) }
        val progress = if (vm.durationMs > 0) (vm.positionMs.toFloat() / vm.durationMs).coerceIn(0f, 1f) else 0f

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            ArtWithReflection(
                vm, e, pod?.title ?: "", progress,
                Modifier.padding(start = 28.dp, end = 28.dp, top = 12.dp).fillMaxWidth(),
            )

            // Title and podcast.
            Column(Modifier.padding(horizontal = 28.dp).padding(top = 10.dp)) {
                Text(e.title, fontSize = 20.sp, lineHeight = 25.sp, fontWeight = FontWeight.ExtraBold, color = c.ink, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(
                    pod?.title ?: "",
                    modifier = Modifier.padding(top = 4.dp).clickable(enabled = pod != null) { pod?.let { vm.open(Screen.PodcastView(it.feedUrl)) } },
                    fontSize = 14.sp, color = c.sticker, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }

            SeekBar(vm.positionMs, vm.durationMs, onSeek = { vm.seek(it) }, modifier = Modifier.padding(horizontal = 28.dp).padding(top = 18.dp))

            // The big controls, right under the cassette.
            Row(
                Modifier.fillMaxWidth().padding(top = 10.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                PressButton(onClick = { vm.skip(-15) }, size = 64.dp) { SkipGlyph(back = true) }
                Spacer(Modifier.width(28.dp))
                PressButton(onClick = { vm.toggle() }, size = 80.dp, background = c.sticker, modifier = Modifier.shadow(12.dp, CircleShape)) {
                    Crossfade(vm.isPlaying, label = "playpause") { p -> Glyph(if (p) Ic.Pause else Ic.Play, c.stickerInk, Modifier.size(36.dp)) }
                }
                Spacer(Modifier.width(28.dp))
                PressButton(onClick = { vm.skip(30) }, size = 64.dp) { SkipGlyph(back = false) }
            }

            // Speed and sleep timer.
            Row(
                Modifier.fillMaxWidth().padding(top = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
            ) {
                val si = Speeds.indexOfFirst { kotlin.math.abs(it - vm.speed) < 0.01f }.coerceAtLeast(0)
                Chip("Hastighet " + ("%.1f×".format(vm.speed)).replace('.', ',')) { vm.changeSpeed(Speeds[(si + 1) % Speeds.size]) }
                val sleepLabel = when (val s = vm.sleepLeftMin) {
                    null -> "Insomning av"
                    -1 -> "Sov vid slutet"
                    else -> "Sov om $s min"
                }
                Chip(sleepLabel, on = vm.sleepLeftMin != null) {
                    val cur = Sleeps.indexOf(vm.sleepLeftMin.let { if (it != null && it > 0) Sleeps.filterNotNull().filter { s -> s > 0 }.firstOrNull { s -> s >= it } else it })
                    vm.setSleep(Sleeps[(cur + 1).coerceAtLeast(1) % Sleeps.size])
                }
            }

            // Notes, chapters and the queue.
            val tabs = buildList {
                add("Om avsnittet")
                if (chapters.isNotEmpty()) add("Kapitel")
                add(if (vm.queue.isEmpty()) "Kö" else "Kö · ${vm.queue.size}")
            }
            if (tab >= tabs.size) tab = 0
            Row(Modifier.padding(horizontal = 20.dp).padding(top = 30.dp, bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                tabs.forEachIndexed { i, t -> Chip(t, on = i == tab) { tab = i } }
            }
            when (tabs[tab]) {
                "Om avsnittet" -> Notes(e.notes)
                "Kapitel" -> ChapterList(chapters, vm.positionMs) { vm.seek(it) }
                else -> {
                    if (vm.queue.isEmpty()) {
                        Text("Kön är tom.", modifier = Modifier.padding(20.dp), fontSize = 15.sp, color = c.inkSoft)
                    }
                    vm.queue.forEach { id ->
                        vm.episode(id)?.let { q ->
                            EpisodeRow(vm, q, showPodcast = true, leftLabel = "Ta bort ur kön", leftAction = { vm.removeFromQueue(id) }) {
                                vm.open(Screen.EpisodeView(id))
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

/**
 * The cassette, the reel-to-reel or the cover, mirrored beneath like on a glossy shelf.
 * Tap to switch to the cover, hold to change the picture.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ArtWithReflection(vm: MainViewModel, e: Episode, showName: String, progress: Float, modifier: Modifier) {
    val pod = vm.podcast(e.feedUrl)
    val cover = e.imageUrl.ifEmpty { pod?.imageUrl ?: "" }
    val src = remember { MutableInteractionSource() }
    val look = if (vm.showCover && cover.isNotEmpty()) -1 else vm.playerLook
    Crossfade(look, modifier = modifier, label = "art") { mode ->
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val artW = if (mode == -1) maxWidth * 0.74f else maxWidth
            val artH = when (mode) {
                -1 -> artW
                2 -> maxWidth / 1.25f
                else -> maxWidth / 1.6f
            }
            val art: @Composable (Modifier) -> Unit = { m ->
                when (mode) {
                    -1 -> CoverArt(cover, m)
                    2 -> ReelToReel(e.title, showName, cover, progress, vm.isPlaying, m)
                    else -> Cassette(e.title, showName, cover, progress, vm.isPlaying, mode == 1, m)
                }
            }
            Column(
                Modifier.fillMaxWidth().combinedClickable(
                    interactionSource = src,
                    indication = null,
                    onLongClick = {
                        if (vm.showCover && cover.isNotEmpty()) vm.toggleArt() else vm.pickPlayerLook((vm.playerLook + 1) % 3)
                    },
                    onClick = { vm.toggleArt() },
                ),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                art(Modifier.width(artW).height(artH))
                // The mirror image: upside down, fading out, only the top part shown.
                Box(Modifier.padding(top = 6.dp).width(artW).height(artH * 0.3f).clipToBounds()) {
                    art(
                        Modifier
                            .wrapContentHeight(Alignment.Top, unbounded = true)
                            .width(artW)
                            .height(artH)
                            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                            .drawWithContent {
                                drawContent()
                                drawRect(
                                    Brush.verticalGradient(
                                        listOf(Color.Black.copy(alpha = 0.30f), Color.Transparent),
                                        startY = 0f, endY = size.height * 0.3f,
                                    ),
                                    blendMode = BlendMode.DstIn,
                                )
                            }
                            .graphicsLayer { scaleY = -1f },
                    )
                }
            }
        }
    }
}

@Composable
private fun CoverArt(url: String, modifier: Modifier) {
    val c = LocalSkiv.current
    Box(modifier.shadow(16.dp, RoundedCornerShape(14.dp)).clip(RoundedCornerShape(14.dp)).background(c.chip)) {
        AsyncImage(model = url, contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}

@Composable
private fun SkipGlyph(back: Boolean) {
    val c = LocalSkiv.current
    Box(contentAlignment = Alignment.Center) {
        Glyph(if (back) Ic.ArcBack else Ic.ArcFwd, c.ink, Modifier.size(42.dp))
        Text(if (back) "15" else "30", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = c.ink, modifier = Modifier.padding(top = 2.dp))
    }
}

/** Thin timeline: tap or drag anywhere on it. */
@Composable
private fun SeekBar(positionMs: Long, durationMs: Long, onSeek: (Long) -> Unit, modifier: Modifier) {
    val c = LocalSkiv.current
    var drag by remember { mutableStateOf<Float?>(null) }
    val dur = durationMs.coerceAtLeast(1L)
    val frac = drag ?: (positionMs.toFloat() / dur).coerceIn(0f, 1f)
    Column(modifier.fillMaxWidth()) {
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(22.dp)
                .pointerInput(dur) { detectTapGestures { o -> onSeek(((o.x / size.width).coerceIn(0f, 1f) * dur).toLong()) } }
                .pointerInput(dur) {
                    detectHorizontalDragGestures(
                        onDragStart = { o -> drag = (o.x / size.width).coerceIn(0f, 1f) },
                        onDragEnd = { drag?.let { onSeek((it * dur).toLong()) }; drag = null },
                        onDragCancel = { drag = null },
                    ) { change, _ ->
                        change.consume()
                        drag = (change.position.x / size.width).coerceIn(0f, 1f)
                    }
                },
        ) {
            val h = if (drag != null) 6.dp.toPx() else 4.dp.toPx()
            val y = size.height / 2f - h / 2f
            drawRoundRect(c.line, Offset(0f, y), Size(size.width, h), CornerRadius(h))
            drawRoundRect(if (drag != null) c.sticker else c.ink, Offset(0f, y), Size(size.width * frac, h), CornerRadius(h))
            if (drag != null) drawCircle(c.sticker, 8.dp.toPx(), Offset(size.width * frac, size.height / 2f))
        }
        Row(Modifier.fillMaxWidth()) {
            Text(fmtTime((frac * dur).toLong()), fontSize = 11.sp, color = c.inkSoft, modifier = Modifier.weight(1f))
            Text("-" + fmtTime(((1f - frac) * dur).toLong()), fontSize = 11.sp, color = c.inkSoft)
        }
    }
}

/** Turning reels: constant tape speed, so the reel holding less tape turns faster. */
private class ReelAngles {
    var left by mutableFloatStateOf(0f)
    var right by mutableFloatStateOf(0f)
}

@Composable
private fun rememberReelAngles(playing: Boolean, progress: Float, speed: Float = 70f): ReelAngles {
    val angles = remember { ReelAngles() }
    val playingState = rememberUpdatedState(playing)
    val progressState = rememberUpdatedState(progress)
    LaunchedEffect(Unit) {
        var last = 0L
        var run = 0f
        while (true) {
            if (!playingState.value && run < 0.02f) {
                run = 0f
                last = 0L
                snapshotFlow { playingState.value }.first { it }
            }
            withFrameNanos { now ->
                if (last != 0L) {
                    val dt = ((now - last) / 1e9f).coerceAtMost(0.1f)
                    run += ((if (playingState.value) 1f else 0f) - run) * (dt * 4f).coerceAtMost(1f)
                    val p = progressState.value
                    val rl = 0.35f + 0.65f * sqrt(1f - p)
                    val rr = 0.35f + 0.65f * sqrt(p)
                    angles.left = (angles.left + run * dt * speed / rl) % 360f
                    angles.right = (angles.right + run * dt * speed / rr) % 360f
                }
                last = now
            }
        }
    }
    return angles
}

/** Greyer, faded colours for a printed picture on an old label. */
private val fadedPrint = ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0.55f) })

/**
 * A cassette tape with the cover printed on the label. [worn] gives it yellowed paper,
 * a coffee ring, a torn corner, tape and scratches.
 */
@Composable
private fun Cassette(title: String, show: String, cover: String, progress: Float, playing: Boolean, worn: Boolean, modifier: Modifier) {
    val c = LocalSkiv.current
    val reels = rememberReelAngles(playing, progress)
    val accent = if (worn) lerp(c.sticker, Color(0xFFD8C7A0), 0.35f) else c.sticker
    val paperTop = if (worn) Color(0xFFEDDFBC) else Color(0xFFF8F3E7)
    val paperBottom = if (worn) Color(0xFFD4BE92) else Color(0xFFE7DEC8)
    val ink = if (worn) Color(0xFF3B3427) else Color(0xFF1C1C18)
    BoxWithConstraints(modifier.aspectRatio(1.6f)) {
        val bw = maxWidth
        Canvas(Modifier.fillMaxSize().shadow(18.dp, RoundedCornerShape(16.dp))) {
            val w = size.width
            val h = size.height
            val shell = Color(0xFF2A2D31)

            // Shell: dark plastic, lit from above, with a bevelled edge.
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0xFF43474D), shell, Color(0xFF1B1D20))),
                size = size, cornerRadius = CornerRadius(w * 0.045f),
            )
            drawRoundRect(
                Color.White.copy(alpha = 0.12f), Offset(w * 0.005f, w * 0.005f), Size(w * 0.99f, h - w * 0.01f),
                CornerRadius(w * 0.042f), style = Stroke(w * 0.004f),
            )
            drawRect(Color(0xFF15171A), Offset(w * 0.11f, 0f), Size(w * 0.05f, h * 0.035f))
            drawRect(Color(0xFF15171A), Offset(w * 0.84f, 0f), Size(w * 0.05f, h * 0.035f))
            listOf(Offset(w * 0.035f, h * 0.065f), Offset(w * 0.965f, h * 0.065f), Offset(w * 0.035f, h * 0.935f), Offset(w * 0.965f, h * 0.935f))
                .forEach { screw(it, w * 0.016f) }

            // Paper label.
            val lt = Offset(w * 0.07f, h * 0.075f)
            val ls = Size(w * 0.86f, h * 0.64f)
            drawRoundRect(Color.Black.copy(alpha = 0.35f), lt + Offset(0f, w * 0.005f), ls, CornerRadius(w * 0.022f))
            drawRoundRect(
                Brush.verticalGradient(listOf(paperTop, paperBottom), startY = lt.y, endY = lt.y + ls.height),
                lt, ls, CornerRadius(w * 0.022f),
            )
            drawLine(
                Color(0x26000000), Offset(lt.x + ls.width * 0.22f, lt.y + ls.height * 0.42f),
                Offset(lt.x + ls.width * 0.96f, lt.y + ls.height * 0.42f), w * 0.0025f,
            )
            drawRect(lerp(accent, Color.White, 0.45f), Offset(lt.x, lt.y + ls.height * 0.47f), Size(ls.width, ls.height * 0.03f))
            drawRect(accent, Offset(lt.x, lt.y + ls.height * 0.50f), Size(ls.width, ls.height * 0.32f))
            drawRect(lerp(accent, Color.Black, 0.3f), Offset(lt.x, lt.y + ls.height * 0.82f), Size(ls.width, ls.height * 0.05f))
            if (worn) wornLabel(lt, ls, w, shell)

            // Window of smoked plastic.
            val wt = Offset(w * 0.23f, h * 0.37f)
            val ws = Size(w * 0.54f, h * 0.23f)
            val rim = w * 0.012f
            drawRoundRect(Color(0xFF15171A), wt - Offset(rim, rim), Size(ws.width + rim * 2f, ws.height + rim * 2f), CornerRadius(ws.height * 0.5f + rim))
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0xFF282C31), Color(0xFF0F1113)), startY = wt.y, endY = wt.y + ws.height),
                wt, ws, CornerRadius(ws.height * 0.5f),
            )
            val cl = Offset(w * 0.355f, wt.y + ws.height / 2f)
            val cr = Offset(w * 0.645f, wt.y + ws.height / 2f)
            val rMin = w * 0.05f
            val rMax = w * 0.13f
            val rl = rMin + (rMax - rMin) * sqrt(1f - progress)
            val rr = rMin + (rMax - rMin) * sqrt(progress)
            clipRect(wt.x, wt.y, wt.x + ws.width, wt.y + ws.height) {
                tapePack(cl, rl, rMin)
                tapePack(cr, rr, rMin)
                hub(cl, rMin * 0.85f, reels.left)
                hub(cr, rMin * 0.85f, reels.right)
                drawPath(Path().apply {
                    moveTo(wt.x + ws.width * 0.12f, wt.y)
                    lineTo(wt.x + ws.width * 0.30f, wt.y)
                    lineTo(wt.x + ws.width * 0.20f, wt.y + ws.height)
                    lineTo(wt.x + ws.width * 0.02f, wt.y + ws.height)
                    close()
                }, Color.White.copy(alpha = if (worn) 0.04f else 0.07f))
            }
            drawRoundRect(Color.White.copy(alpha = 0.10f), wt, ws, CornerRadius(ws.height * 0.5f), style = Stroke(w * 0.003f))

            // Bottom bridge where the tape runs past the heads.
            val bridge = Path().apply {
                moveTo(w * 0.17f, h)
                lineTo(w * 0.23f, h * 0.77f)
                lineTo(w * 0.77f, h * 0.77f)
                lineTo(w * 0.83f, h)
                close()
            }
            drawPath(bridge, Brush.verticalGradient(listOf(Color(0xFF24272B), Color(0xFF141618)), startY = h * 0.77f, endY = h))
            drawPath(bridge, Color.White.copy(alpha = 0.08f), style = Stroke(w * 0.003f))
            listOf(0.30f, 0.39f, 0.61f, 0.70f).forEach { fx ->
                drawRoundRect(Color(0xFF0A0B0C), Offset(w * fx - w * 0.018f, h * 0.885f), Size(w * 0.036f, h * 0.05f), CornerRadius(w * 0.006f))
            }
            drawRoundRect(Color(0xFF0A0B0C), Offset(w * 0.455f, h * 0.875f), Size(w * 0.09f, h * 0.07f), CornerRadius(w * 0.008f))
            drawRect(Color(0xFFB89A6A), Offset(w * 0.475f, h * 0.85f), Size(w * 0.05f, h * 0.022f))
            val ty = h * 0.865f
            drawLine(Color(0xFF5E412E), Offset(w * 0.12f, ty), Offset(w * 0.88f, ty), w * 0.008f)
            listOf(0.12f, 0.88f).forEach { fx ->
                drawCircle(Color(0xFFDAD7CD), w * 0.017f, Offset(w * fx, ty))
                drawCircle(Color(0xFF6B6B66), w * 0.006f, Offset(w * fx, ty))
            }
            if (worn) scratches(w, h)
        }
        // Cover, show and title, printed on the label.
        Row(
            Modifier.fillMaxWidth().padding(start = bw * 0.095f, end = bw * 0.09f, top = bw * 0.06f),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (cover.isNotEmpty()) {
                AsyncImage(
                    model = cover, contentDescription = null, contentScale = ContentScale.Crop,
                    colorFilter = if (worn) fadedPrint else null,
                    modifier = Modifier.size(bw * 0.14f).clip(RoundedCornerShape(3.dp)).graphicsLayer { alpha = if (worn) 0.85f else 1f },
                )
            } else {
                Box(Modifier.size(bw * 0.07f).clip(CircleShape).background(accent), contentAlignment = Alignment.Center) {
                    Text("A", fontSize = 12.sp, fontWeight = FontWeight.Black, color = c.stickerInk)
                }
            }
            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                Text(show.uppercase(), fontSize = 10.sp, letterSpacing = 0.12.em, color = ink.copy(alpha = 0.6f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(title, fontSize = 14.sp, lineHeight = 17.sp, fontWeight = FontWeight.Bold, color = ink, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            if (cover.isNotEmpty()) {
                Box(Modifier.padding(start = 6.dp).size(bw * 0.055f).clip(CircleShape).background(accent), contentAlignment = Alignment.Center) {
                    Text("A", fontSize = 10.sp, fontWeight = FontWeight.Black, color = c.stickerInk)
                }
            }
        }
        Text(
            "C90", modifier = Modifier.align(Alignment.TopStart).padding(start = bw * 0.095f, top = bw * 0.295f),
            fontSize = 12.sp, fontWeight = FontWeight.Black, color = c.stickerInk,
        )
        Text(
            "STEREO", modifier = Modifier.align(Alignment.TopEnd).padding(end = bw * 0.09f, top = bw * 0.3f),
            fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.14.em, color = c.stickerInk,
        )
    }
}

/** Years in a car door: brown edges, a coffee ring, a torn corner, a bit of tape and specks. */
private fun DrawScope.wornLabel(lt: Offset, ls: Size, w: Float, shell: Color) {
    val corner = CornerRadius(w * 0.022f)
    drawRoundRect(Color(0x2E5A3A12), lt, ls, corner, style = Stroke(w * 0.014f))
    // Coffee ring.
    val ringC = Offset(lt.x + ls.width * 0.83f, lt.y + ls.height * 0.24f)
    val ringR = ls.height * 0.2f
    drawCircle(Color(0x12704A1E), ringR, ringC)
    drawCircle(Color(0x38704A1E), ringR, ringC, style = Stroke(w * 0.006f))
    drawCircle(Color(0x1C704A1E), ringR * 0.93f, ringC + Offset(w * 0.004f, w * 0.003f), style = Stroke(w * 0.003f))
    // Torn-off bottom-right corner shows the plastic beneath.
    val br = Offset(lt.x + ls.width, lt.y + ls.height)
    drawPath(Path().apply {
        moveTo(br.x + 1f, br.y - ls.height * 0.22f)
        lineTo(br.x - ls.width * 0.02f, br.y - ls.height * 0.14f)
        lineTo(br.x - ls.width * 0.05f, br.y - ls.height * 0.07f)
        lineTo(br.x - ls.width * 0.11f, br.y + 1f)
        lineTo(br.x + 1f, br.y + 1f)
        close()
    }, shell)
    // A strip of old tape over the top-left corner.
    rotate(-32f, Offset(lt.x + ls.width * 0.03f, lt.y + ls.height * 0.05f)) {
        drawRect(Color(0x55FFF3C4), Offset(lt.x - ls.width * 0.05f, lt.y), Size(ls.width * 0.16f, ls.height * 0.08f))
    }
    // Specks and faded spots.
    val rnd = Random(11)
    repeat(40) {
        val p = Offset(lt.x + rnd.nextFloat() * ls.width, lt.y + rnd.nextFloat() * ls.height)
        drawCircle(Color(0xFF4A3A20).copy(alpha = 0.05f + rnd.nextFloat() * 0.12f), w * (0.0015f + rnd.nextFloat() * 0.003f), p)
    }
    repeat(4) {
        val p = Offset(lt.x + rnd.nextFloat() * ls.width, lt.y + rnd.nextFloat() * ls.height)
        drawCircle(Color.White.copy(alpha = 0.10f), w * (0.02f + rnd.nextFloat() * 0.03f), p)
    }
}

/** Light scratches and scuffs across the plastic. */
private fun DrawScope.scratches(w: Float, h: Float) {
    val rnd = Random(5)
    repeat(26) {
        val x = rnd.nextFloat() * w
        val y = rnd.nextFloat() * h
        val len = w * (0.02f + rnd.nextFloat() * 0.09f)
        val a = (rnd.nextFloat() - 0.5f) * 1.2f
        drawLine(
            Color.White.copy(alpha = 0.06f + rnd.nextFloat() * 0.10f),
            Offset(x, y), Offset(x + len * kotlin.math.cos(a), y + len * kotlin.math.sin(a)), 1f,
        )
    }
    listOf(Offset(w * 0.02f, h * 0.5f), Offset(w * 0.98f, h * 0.3f), Offset(w * 0.5f, h * 0.99f)).forEach {
        drawCircle(Color.White.copy(alpha = 0.06f), w * 0.035f, it)
    }
}

/**
 * A reel-to-reel tape recorder: two metal reels on brushed aluminium, the tape running
 * past the heads, and a name plate with the cover.
 */
@Composable
private fun ReelToReel(title: String, show: String, cover: String, progress: Float, playing: Boolean, modifier: Modifier) {
    val c = LocalSkiv.current
    val reels = rememberReelAngles(playing, progress, speed = 45f)
    val lamp by animateFloatAsState(if (playing) 1f else 0.15f, label = "lamp")
    val accent = c.sticker
    BoxWithConstraints(modifier.aspectRatio(1.25f)) {
        val bw = maxWidth
        Canvas(Modifier.fillMaxSize().shadow(18.dp, RoundedCornerShape(14.dp))) {
            val w = size.width
            val h = size.height
            val corner = CornerRadius(w * 0.035f)
            // Brushed aluminium front.
            drawRoundRect(Brush.verticalGradient(listOf(Color(0xFFDADDDF), Color(0xFFBBBFC2), Color(0xFFA2A6A9))), size = size, cornerRadius = corner)
            clipRect(w * 0.02f, h * 0.01f, w * 0.98f, h * 0.99f) {
                for (i in 0 until 90) {
                    val y = h * i / 90f
                    drawLine(Color.White.copy(alpha = if (i % 3 == 0) 0.14f else 0.05f), Offset(0f, y), Offset(w, y), 1f)
                }
            }
            drawRoundRect(Color.Black.copy(alpha = 0.28f), Offset.Zero, size, corner, style = Stroke(w * 0.004f))

            // Dark lower deck.
            val deckTop = h * 0.66f
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0xFF2C2F32), Color(0xFF191B1D)), startY = deckTop, endY = h),
                Offset(w * 0.03f, deckTop), Size(w * 0.94f, h * 0.31f), CornerRadius(w * 0.02f),
            )

            val reelR = w * 0.215f
            val cl = Offset(w * 0.27f, h * 0.33f)
            val cr = Offset(w * 0.73f, h * 0.33f)
            val core = reelR * 0.30f
            val packMax = reelR * 0.92f
            val rl = core + (packMax - core) * sqrt(1f - progress)
            val rr = core + (packMax - core) * sqrt(progress)

            // Tape path: out of the left reel, round the guides, past the heads, into the right reel.
            val tape = Color(0xFF4A3121)
            val gl = Offset(w * 0.10f, h * 0.74f)
            val gr = Offset(w * 0.90f, h * 0.74f)
            val headY = h * 0.80f
            drawPath(Path().apply {
                moveTo(cl.x - rl * 0.97f, cl.y + rl * 0.25f)
                lineTo(gl.x - w * 0.022f, gl.y)
                lineTo(w * 0.30f, headY)
                lineTo(w * 0.70f, headY)
                lineTo(gr.x + w * 0.022f, gr.y)
                lineTo(cr.x + rr * 0.97f, cr.y + rr * 0.25f)
            }, tape, style = Stroke(w * 0.007f))

            reel(cl, reelR, core, rl, reels.left)
            reel(cr, reelR, core, rr, reels.right)

            // Guides, head block, capstan and pinch roller.
            listOf(gl, gr).forEach { g ->
                drawCircle(Brush.radialGradient(listOf(Color(0xFFF4F5F6), Color(0xFF85898D)), center = g, radius = w * 0.024f), w * 0.022f, g)
                drawCircle(Color(0xFF3A3D40), w * 0.006f, g)
            }
            drawRoundRect(Color(0xFF0E0F10), Offset(w * 0.36f, h * 0.745f), Size(w * 0.28f, h * 0.10f), CornerRadius(w * 0.012f))
            listOf(0.40f, 0.475f, 0.55f).forEach { fx ->
                drawRoundRect(
                    Brush.verticalGradient(listOf(Color(0xFFE9EBED), Color(0xFF7D8185)), startY = h * 0.76f, endY = h * 0.80f),
                    Offset(w * fx, h * 0.76f), Size(w * 0.05f, h * 0.04f), CornerRadius(w * 0.008f),
                )
            }
            drawCircle(Color(0xFFCDD0D3), w * 0.010f, Offset(w * 0.72f, headY))
            drawCircle(Color(0xFF111213), w * 0.026f, Offset(w * 0.72f, headY + w * 0.036f))
            drawCircle(Color(0xFF2C2E30), w * 0.012f, Offset(w * 0.72f, headY + w * 0.036f))

            // Power lamp.
            val lampAt = Offset(w * 0.93f, h * 0.70f)
            drawCircle(accent.copy(alpha = 0.25f * lamp), w * 0.03f, lampAt)
            drawCircle(lerp(Color(0xFF3A2A20), accent, lamp), w * 0.011f, lampAt)

            // Name plate.
            drawRoundRect(Color(0xFF0F1011), Offset(w * 0.06f, h * 0.86f), Size(w * 0.88f, h * 0.095f), CornerRadius(w * 0.01f))
            drawRoundRect(Color.White.copy(alpha = 0.08f), Offset(w * 0.06f, h * 0.86f), Size(w * 0.88f, h * 0.095f), CornerRadius(w * 0.01f), style = Stroke(1f))
        }
        Row(
            Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .padding(start = bw * 0.075f, end = bw * 0.075f, bottom = bw * 0.036f)
                .height(bw * 0.076f),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (cover.isNotEmpty()) {
                AsyncImage(
                    model = cover, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.size(bw * 0.056f).clip(RoundedCornerShape(2.dp)),
                )
            }
            Text(
                show.uppercase(), modifier = Modifier.padding(start = 8.dp).widthIn(max = bw * 0.3f),
                fontSize = 8.5.sp, letterSpacing = 0.12.em, color = Color(0xFF9FA4A8), maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
            Text(
                title, modifier = Modifier.weight(1f).padding(start = 8.dp),
                fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEDEDE8), maxLines = 1, overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/** A metal reel: the tape pack shows through three windows in the flange, all turning together. */
private fun DrawScope.reel(at: Offset, r: Float, core: Float, pack: Float, angle: Float) {
    drawCircle(Color.Black.copy(alpha = 0.20f), r * 1.01f, at + Offset(r * 0.03f, r * 0.05f))
    drawCircle(
        Brush.linearGradient(listOf(Color(0xFFF3F4F5), Color(0xFF9CA0A4), Color(0xFFE6E8EA)), start = at - Offset(r, r), end = at + Offset(r, r)),
        r, at,
    )
    drawCircle(Color.Black.copy(alpha = 0.28f), r, at, style = Stroke(r * 0.02f))
    rotate(angle, at) {
        for (k in 0 until 3) {
            val start = k * 120f - 35f
            val window = Path().apply {
                arcTo(Rect(at, r * 0.86f), start, 70f, true)
                arcTo(Rect(at, core * 1.3f), start + 70f, -70f, false)
                close()
            }
            drawPath(window, Color(0xFF232527))
            clipPath(window) {
                drawCircle(Brush.radialGradient(listOf(Color(0xFF5E402B), Color(0xFF3C281B)), center = at, radius = pack), pack, at)
                for (i in 1..5) {
                    val k2 = core + (pack - core) * i / 6f
                    if (k2 > core + 1f) drawCircle(Color.Black.copy(alpha = 0.12f), k2, at, style = Stroke(1f))
                }
            }
            drawPath(window, Color.Black.copy(alpha = 0.35f), style = Stroke(r * 0.015f))
        }
    }
    drawCircle(Color(0xFFBFC3C6), core * 1.15f, at)
    hub(at, core * 0.95f, angle)
}

private fun DrawScope.screw(at: Offset, r: Float) {
    drawCircle(Brush.radialGradient(listOf(Color(0xFFC3C8CD), Color(0xFF6A6F74)), center = at, radius = r), r, at)
    drawLine(Color(0xFF2E3134), Offset(at.x - r * 0.6f, at.y - r * 0.2f), Offset(at.x + r * 0.6f, at.y + r * 0.2f), r * 0.3f)
}

/** Wound tape: dark brown with faint rings. */
private fun DrawScope.tapePack(at: Offset, r: Float, core: Float) {
    drawCircle(Brush.radialGradient(listOf(Color(0xFF6E4C35), Color(0xFF4B3324), Color(0xFF3A271B)), center = at, radius = r), r, at)
    for (i in 1..4) {
        val k = core + (r - core) * i / 5f
        if (k > core + 1f) drawCircle(Color.Black.copy(alpha = 0.10f), k, at, style = Stroke(1f))
    }
    drawCircle(Color.White.copy(alpha = 0.10f), r, at, style = Stroke(1.2f))
}

private fun DrawScope.hub(at: Offset, r: Float, angle: Float) {
    drawCircle(Color(0xFFF1EFE8), r, at)
    drawCircle(Color(0xFFCFCBC0), r, at, style = Stroke(r * 0.08f))
    drawCircle(Color(0xFF1B1C1E), r * 0.58f, at)
    rotate(angle, at) {
        for (k in 0 until 6) {
            rotate(k * 60f, at) {
                drawRect(Color(0xFFF1EFE8), Offset(at.x - r * 0.09f, at.y - r * 0.60f), Size(r * 0.18f, r * 0.26f))
            }
        }
        for (k in 0 until 3) {
            rotate(k * 120f + 30f, at) {
                drawCircle(Color(0xFF9A968C), r * 0.08f, Offset(at.x, at.y - r * 0.80f))
            }
        }
    }
}
