package se.podbacken

import android.app.Application
import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import java.util.concurrent.Executors
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Saves outlive the screen: they finish even when the app is closed. */
private val saveScope = CoroutineScope(SupervisorJob() + Executors.newSingleThreadExecutor().asCoroutineDispatcher())

sealed interface Screen {
    data class Home(val tab: Int) : Screen
    data class PodcastView(val feedUrl: String) : Screen
    data class EpisodeView(val id: String) : Screen
    data object Player : Screen
    data object Search : Screen
    data object Settings : Screen
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Context get() = getApplication<Application>()
    private val prefs = app.getSharedPreferences("podbacken", Context.MODE_PRIVATE)

    var screen by mutableStateOf<Screen>(Screen.Home(0))
    private val backStack = ArrayDeque<Screen>()
    fun open(s: Screen) { backStack.addLast(screen); screen = s }
    fun back(): Boolean {
        val prev = backStack.removeLastOrNull() ?: return false
        screen = prev
        return true
    }
    fun home(tab: Int) { backStack.clear(); screen = Screen.Home(tab) }

    var podcasts by mutableStateOf<List<Podcast>>(emptyList()); private set
    var episodes by mutableStateOf<Map<String, List<Episode>>>(emptyMap()); private set
    var refreshing by mutableStateOf(false); private set
    private var byId: Map<String, Episode> = emptyMap()

    var queue by mutableStateOf<List<String>>(emptyList()); private set
    var played by mutableStateOf<Set<String>>(emptySet()); private set
    val positions = mutableStateMapOf<String, Long>()

    var currentId by mutableStateOf<String?>(null); private set
    var isPlaying by mutableStateOf(false); private set
    var positionMs by mutableLongStateOf(0L); private set
    var durationMs by mutableLongStateOf(0L); private set
    var speed by mutableFloatStateOf(prefs.getFloat("speed", 1f)); private set
    /** Minutes left on the sleep timer, -1 for "end of episode", null when off. */
    var sleepLeftMin by mutableStateOf<Int?>(null); private set
    private var sleepJob: Job? = null
    private var sleepAtEnd = false

    private var controller: MediaController? = null
    /** The episode that was playing last time, loaded again (paused) when the app starts. */
    private var restoreId: String? = null
    private var started = false

    fun episode(id: String?): Episode? = id?.let { byId[it] }
    fun podcast(feedUrl: String): Podcast? = podcasts.firstOrNull { it.feedUrl == feedUrl }
    val current: Episode? get() = episode(currentId)

    /** Latest episodes from every subscription, newest first. */
    val latest: List<Episode> get() = episodes.values.flatten().sortedByDescending { it.dateMs }.take(150)

    fun start() {
        if (started) return
        started = true
        viewModelScope.launch {
            val (pods, eps, st) = withContext(Dispatchers.IO) {
                val pods = Store.loadPodcasts(ctx)
                Triple(pods, pods.associate { it.feedUrl to Store.loadEpisodes(ctx, it.feedUrl) }, Store.loadState(ctx))
            }
            podcasts = pods
            putEpisodes(eps)
            loadAuto()
            queue = st.queue.filter { it in byId }
            restoreId = st.current
            played = st.played
            positions.putAll(st.positions)
            connect()
            Downloads.schedule(ctx)
            withContext(Dispatchers.IO) { Downloads.cleanPlayed(ctx, played) }
            refreshAll()
        }
    }

    private fun putEpisodes(map: Map<String, List<Episode>>) {
        episodes = map
        byId = map.values.flatten().associateBy { it.id }
    }

    // ---------- feeds ----------

    fun refreshAll() {
        if (refreshing || podcasts.isEmpty()) return
        viewModelScope.launch {
            refreshing = true
            for (p in podcasts) {
                val result = withContext(Dispatchers.IO) { runCatching { FeedParser.parse(p.feedUrl, Http.get(p.feedUrl)) } }
                result.getOrNull()?.let { (pod, eps) ->
                    val known = episodes[p.feedUrl].orEmpty().map { it.id }.toSet()
                    withContext(Dispatchers.IO) { Store.saveEpisodes(ctx, p.feedUrl, eps) }
                    markSeen(p.feedUrl, eps)
                    if (p.feedUrl in autoFeeds && known.isNotEmpty()) {
                        eps.filter { it.id !in known && it.id !in played }.take(2).forEach { download(it) }
                    }
                    podcasts = podcasts.map { if (it.feedUrl == p.feedUrl) pod.copy(imageUrl = pod.imageUrl.ifEmpty { it.imageUrl }) else it }
                    putEpisodes(episodes + (p.feedUrl to eps))
                }
            }
            withContext(Dispatchers.IO) { Store.savePodcasts(ctx, podcasts) }
            refreshing = false
        }
    }

    /** Adds a feed (a search hit, or a private link from Patreon and the like). Returns an error text or null. */
    suspend fun subscribe(url: String): String? {
        val clean = url.trim()
        if (!clean.startsWith("http")) return "Länken ska börja med https://"
        if (podcasts.any { it.feedUrl == clean }) return "Du prenumererar redan på den här podden."
        val result = withContext(Dispatchers.IO) { runCatching { FeedParser.parse(clean, Http.get(clean)) } }
        val (pod, eps) = result.getOrElse { return "Kunde inte läsa flödet. Kontrollera länken och nätet. (${it.message})" }
        if (eps.isEmpty()) return "Flödet innehåller inga avsnitt med ljud."
        podcasts = podcasts + pod
        putEpisodes(episodes + (clean to eps))
        markSeen(clean, eps)
        withContext(Dispatchers.IO) {
            Store.saveEpisodes(ctx, clean, eps)
            Store.savePodcasts(ctx, podcasts)
        }
        return null
    }

    /** Episodes shown in the app don't need a notice later. */
    private fun markSeen(feedUrl: String, eps: List<Episode>) {
        prefs.edit().putStringSet("seen:" + stableId(feedUrl), eps.map { it.id }.toSet()).apply()
    }

    /** Moves a podcast in the user's own order (drag in the grid). */
    fun movePodcast(from: Int, to: Int) {
        if (from == to || from !in podcasts.indices || to !in podcasts.indices) return
        podcasts = podcasts.toMutableList().apply { add(to, removeAt(from)) }
    }

    fun saveOrder() {
        val list = podcasts
        viewModelScope.launch(Dispatchers.IO) { Store.savePodcasts(ctx, list) }
    }

    /** How the podcasts tab looks: 0 grid, 1 list, 2 cassettes. */
    var podView by mutableStateOf(prefs.getInt("podView", 0)); private set
    fun pickPodView(v: Int) { podView = v; prefs.edit().putInt("podView", v).apply() }

    /** Player picture: 0 cassette, 1 worn cassette, 2 reel-to-reel. */
    var playerLook by mutableStateOf(prefs.getInt("playerLook", 0).coerceIn(0, 2)); private set
    fun pickPlayerLook(v: Int) {
        playerLook = v.coerceIn(0, 2)
        prefs.edit().putInt("playerLook", playerLook).apply()
    }

    /** The player shows the cover instead of the cassette. */
    var showCover by mutableStateOf(prefs.getBoolean("showCover", false)); private set
    fun toggleArt() {
        showCover = !showCover
        prefs.edit().putBoolean("showCover", showCover).apply()
    }

    fun newCount(feedUrl: String): Int =
        episodes[feedUrl].orEmpty().take(20).count { it.id !in played && (positions[it.id] ?: 0L) == 0L }

    /** The podcast whose settings sheet is open, or null. */
    var settingsFeed by mutableStateOf<String?>(null); private set
    fun openPodSettings(feedUrl: String) { settingsFeed = feedUrl }
    fun closePodSettings() { settingsFeed = null }

    fun unsubscribe(feedUrl: String) {
        settingsFeed = null
        val ids = episodes[feedUrl].orEmpty().map { it.id }.toSet()
        podcasts = podcasts.filterNot { it.feedUrl == feedUrl }
        putEpisodes(episodes - feedUrl)
        queue = queue.filterNot { it in ids }
        syncQueue()
        viewModelScope.launch(Dispatchers.IO) {
            Store.deleteEpisodes(ctx, feedUrl)
            Store.savePodcasts(ctx, podcasts)
        }
        saveSoon()
    }

    // ---------- progress ----------

    fun progressOf(e: Episode): Float {
        if (e.id in played) return 1f
        val dur = if (e.id == currentId && durationMs > 0) durationMs else e.durationSec * 1000
        val pos = if (e.id == currentId) positionMs else positions[e.id] ?: 0L
        return if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f
    }

    fun markPlayed(e: Episode, value: Boolean) {
        played = if (value) played + e.id else played - e.id
        if (value) {
            if (e.id != currentId) removeDownload(e)
            positions.remove(e.id)
            queue = queue - e.id
            syncQueue()
        }
        saveSoon()
    }

    private var saveJob: Job? = null
    private fun saveSoon() {
        saveJob?.cancel()
        saveJob = viewModelScope.launch {
            delay(800)
            saveNow()
        }
    }

    fun saveNow() {
        val id = currentId
        val c = controller
        if (id != null && c != null && c.currentMediaItem?.mediaId == id && c.currentPosition > 0L) {
            positions[id] = c.currentPosition
        }
        val q = queue; val p = played; val pos = positions.toMap(); val cur = currentId ?: restoreId
        saveScope.launch { Store.saveState(ctx, q, p, pos, cur) }
    }

    /** After a restart: put the last episode back in the player, paused where you stopped. */
    private fun restoreLast(c: MediaController) {
        val e = episode(restoreId) ?: return
        queue = queue - e.id
        c.setMediaItems(listOf(item(e)) + queue.mapNotNull { episode(it)?.let(::item) }, 0, startPos(e))
        c.prepare()
        c.playbackParameters = PlaybackParameters(speed)
        currentId = e.id
    }

    // ---------- player ----------

    private fun item(e: Episode): MediaItem {
        val pod = podcast(e.feedUrl)
        val art = e.imageUrl.ifEmpty { pod?.imageUrl ?: "" }
        return MediaItem.Builder()
            .setMediaId(e.id)
            .setUri(Downloads.file(ctx, e).takeIf { it.exists() }?.let { Uri.fromFile(it) } ?: Uri.parse(e.audioUrl))
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(e.title)
                    .setArtist(pod?.title)
                    .setAlbumTitle(pod?.title)
                    .apply { if (art.isNotEmpty()) setArtworkUri(Uri.parse(art)) }
                    .build()
            )
            .build()
    }

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync()

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val prev = currentId
            if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO && prev != null) {
                played = played + prev
                positions.remove(prev)
                if (sleepAtEnd) {
                    controller?.pause()
                    cancelSleep()
                }
            }
            val now = mediaItem?.mediaId
            if (now != null && now in queue) queue = queue - now
            currentId = now
            // Next episode in the queue: pick up where you left off, or after the intro.
            if (now != null && (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO || reason == Player.MEDIA_ITEM_TRANSITION_REASON_SEEK)) {
                val next = episode(now)
                val start = if (next != null) startPos(next) else 0L
                if (start > 0L) controller?.seekTo(start)
            }
            saveSoon()
        }

        override fun onPlaybackStateChanged(state: Int) {
            if (state == Player.STATE_ENDED) {
                currentId?.let { played = played + it; positions.remove(it) }
                if (sleepAtEnd) cancelSleep()
                saveSoon()
            }
        }

        override fun onIsPlayingChanged(playing: Boolean) {
            if (!playing) saveSoon()
        }

        override fun onPlayerError(error: PlaybackException) {
            Toast.makeText(ctx, "Kunde inte spela avsnittet (${error.errorCodeName}). Kontrollera nätet.", Toast.LENGTH_LONG).show()
        }
    }

    private fun connect() {
        PlaybackHub.appActive = true
        val token = SessionToken(ctx, ComponentName(ctx, PlaybackService::class.java))
        val future = MediaController.Builder(ctx, token).buildAsync()
        future.addListener({
            controller = runCatching { future.get() }.getOrNull()
            controller?.let {
                it.addListener(listener)
                it.playbackParameters = PlaybackParameters(speed)
                if (it.mediaItemCount == 0) restoreLast(it)
            }
            sync()
        }, ContextCompat.getMainExecutor(ctx))
        viewModelScope.launch {
            var n = 0
            while (true) {
                n++
                // Save progress every 15 seconds while playing, in case the app is closed abruptly.
                if (n % 30 == 0 && isPlaying) saveNow()
                controller?.let { c ->
                    positionMs = c.currentPosition.coerceAtLeast(0)
                    if (c.duration > 0) durationMs = c.duration
                    val id = currentId
                    if (id != null && c.isPlaying) {
                        positions[id] = positionMs
                        checkSkipEnd(c, id)
                    }
                }
                delay(500)
            }
        }
    }

    private fun sync() {
        val c = controller ?: return
        isPlaying = c.isPlaying
        currentId = c.currentMediaItem?.mediaId
        if (c.duration > 0) durationMs = c.duration
    }

    private fun startPos(e: Episode): Long {
        val skip = skipStartOf(e.feedUrl) * 1000L
        if (e.id in played) return skip
        val p = positions[e.id] ?: 0L
        val resume = if (e.durationSec > 0 && p > e.durationSec * 1000 - 5_000) 0L else p
        return maxOf(resume, skip)
    }

    private var endSkippedFor: String? = null

    /** "Skip the end" for this podcast: count the episode as heard and go on with the queue. */
    private fun checkSkipEnd(c: MediaController, id: String) {
        val e = episode(id) ?: return
        val skip = skipEndOf(e.feedUrl) * 1000L
        val dur = c.duration
        if (skip <= 0L || dur <= skip + 10_000L || endSkippedFor == id) return
        if (c.currentPosition < dur - skip) return
        endSkippedFor = id
        played = played + id
        positions.remove(id)
        if (sleepAtEnd) {
            c.pause()
            cancelSleep()
        }
        if (c.hasNextMediaItem()) c.seekToNextMediaItem() else c.pause()
        saveSoon()
    }

    fun play(e: Episode) {
        val c = controller ?: return
        endSkippedFor = null
        if (e.id == currentId) {
            if (!c.isPlaying) c.play()
            return
        }
        currentId?.let { positions[it] = c.currentPosition }
        if (e.id in played) played = played - e.id
        queue = queue - e.id
        val items = listOf(item(e)) + queue.mapNotNull { episode(it)?.let(::item) }
        c.setMediaItems(items, 0, startPos(e))
        c.prepare()
        c.playbackParameters = PlaybackParameters(speed)
        c.play()
        saveSoon()
    }

    /** Rebuilds what comes after the current episode so the player follows the queue. */
    private fun syncQueue() {
        val c = controller ?: return
        if (c.mediaItemCount == 0) return
        val cur = c.currentMediaItemIndex
        if (cur + 1 < c.mediaItemCount) c.removeMediaItems(cur + 1, c.mediaItemCount)
        if (cur > 0) c.removeMediaItems(0, cur)
        c.addMediaItems(queue.mapNotNull { episode(it)?.let(::item) })
    }

    fun playNext(e: Episode) {
        if (e.id == currentId) return
        queue = listOf(e.id) + (queue - e.id)
        afterQueueChange("Spelas härnäst")
    }

    fun addToQueue(e: Episode) {
        if (e.id == currentId) return
        queue = (queue - e.id) + e.id
        afterQueueChange("Lagt sist i kön")
    }

    fun removeFromQueue(id: String) {
        queue = queue - id
        syncQueue()
        saveSoon()
    }

    fun moveInQueue(id: String, by: Int) {
        val i = queue.indexOf(id)
        val j = (i + by).coerceIn(0, queue.size - 1)
        if (i < 0 || i == j) return
        queue = queue.toMutableList().apply { add(j, removeAt(i)) }
        syncQueue()
        saveSoon()
    }

    private fun afterQueueChange(msg: String) {
        if (controller?.mediaItemCount == 0 || currentId == null) {
            // Nothing playing: start the first one in the queue paused, ready to go.
            val first = episode(queue.firstOrNull()) ?: return
            Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
            queue = queue.drop(1)
            controller?.let { c ->
                c.setMediaItems(listOf(item(first)) + queue.mapNotNull { episode(it)?.let(::item) }, 0, startPos(first))
                c.prepare()
            }
        } else {
            syncQueue()
            Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
        }
        saveSoon()
    }

    // ---------- per-podcast settings ----------

    /** Bumped when a podcast's own settings change, so screens redraw. */
    var podSettingsVersion by mutableIntStateOf(0); private set
    private fun podKey(name: String, feedUrl: String) = name + ":" + stableId(feedUrl)

    fun sortOldest(feedUrl: String): Boolean {
        podSettingsVersion
        return prefs.getBoolean(podKey("sortOld", feedUrl), false)
    }
    fun pickSortOldest(feedUrl: String, on: Boolean) {
        prefs.edit().putBoolean(podKey("sortOld", feedUrl), on).apply()
        podSettingsVersion++
    }

    /** Seconds to skip at the start / end of every episode of this podcast. */
    fun skipStartOf(feedUrl: String): Int {
        podSettingsVersion
        return prefs.getInt(podKey("skipStart", feedUrl), 0)
    }
    fun skipEndOf(feedUrl: String): Int {
        podSettingsVersion
        return prefs.getInt(podKey("skipEnd", feedUrl), 0)
    }
    fun changeSkipStart(feedUrl: String, seconds: Int) {
        prefs.edit().putInt(podKey("skipStart", feedUrl), seconds.coerceIn(0, 600)).apply()
        podSettingsVersion++
    }
    fun changeSkipEnd(feedUrl: String, seconds: Int) {
        prefs.edit().putInt(podKey("skipEnd", feedUrl), seconds.coerceIn(0, 600)).apply()
        podSettingsVersion++
    }

    // ---------- downloads ----------

    /** Bumped when a download finishes or is removed, so lists redraw their icons. */
    var downloadsVersion by mutableStateOf(0); private set

    fun isDownloaded(e: Episode): Boolean { downloadsVersion; return Downloads.has(ctx, e) }

    fun download(e: Episode) {
        viewModelScope.launch {
            val ok = Downloads.fetch(ctx, e)
            downloadsVersion++
            Toast.makeText(ctx, if (ok) "Nedladdat: ${e.title}" else "Kunde inte ladda ner avsnittet", Toast.LENGTH_SHORT).show()
        }
    }

    fun removeDownload(e: Episode) {
        Downloads.delete(ctx, e)
        downloadsVersion++
    }

    var autoFeeds by mutableStateOf<Set<String>>(emptySet()); private set
    var notifyFeeds by mutableStateOf<Set<String>>(emptySet()); private set
    fun loadAuto() {
        autoFeeds = Downloads.autoFeeds(ctx)
        notifyFeeds = Downloads.notifyFeeds(ctx)
    }
    fun setNotify(feedUrl: String, on: Boolean) {
        Downloads.setNotify(ctx, feedUrl, on)
        notifyFeeds = Downloads.notifyFeeds(ctx)
    }
    fun setAuto(feedUrl: String, on: Boolean) {
        Downloads.setAuto(ctx, feedUrl, on)
        autoFeeds = Downloads.autoFeeds(ctx)
        if (on) episodes[feedUrl]?.firstOrNull()?.takeIf { it.id !in played }?.let { download(it) }
    }

    fun toggle() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun skip(seconds: Int) {
        val c = controller ?: return
        val target = (c.currentPosition + seconds * 1000L).coerceIn(0L, if (c.duration > 0) c.duration else Long.MAX_VALUE)
        c.seekTo(target)
        positionMs = target
    }

    fun seek(ms: Long) { controller?.seekTo(ms); positionMs = ms }

    fun changeSpeed(s: Float) {
        speed = s
        controller?.playbackParameters = PlaybackParameters(s)
        prefs.edit().putFloat("speed", s).apply()
    }

    /** minutes > 0: pause after that long; -1: pause when the episode ends; null: off. */
    fun setSleep(minutes: Int?) {
        cancelSleep()
        when {
            minutes == null -> Unit
            minutes < 0 -> { sleepAtEnd = true; sleepLeftMin = -1 }
            else -> {
                sleepLeftMin = minutes
                sleepJob = viewModelScope.launch {
                    var left = minutes
                    while (left > 0) {
                        delay(60_000)
                        left--
                        sleepLeftMin = left
                    }
                    controller?.pause()
                    sleepLeftMin = null
                }
            }
        }
    }

    private fun cancelSleep() {
        sleepJob?.cancel()
        sleepJob = null
        sleepAtEnd = false
        sleepLeftMin = null
    }

    suspend fun chapters(e: Episode): List<Chapter> {
        if (e.chaptersUrl.isEmpty()) return emptyList()
        return withContext(Dispatchers.IO) { runCatching { FeedParser.parseChapters(Http.get(e.chaptersUrl)) }.getOrDefault(emptyList()) }
    }

    override fun onCleared() {
        PlaybackHub.appActive = false
        saveNow()
        controller?.removeListener(listener)
        controller?.release()
    }
}
