package se.podbacken

import android.app.PendingIntent
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.core.graphics.drawable.toBitmap
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaLibraryService.LibraryParams
import androidx.media3.session.MediaLibraryService.MediaLibrarySession
import androidx.media3.session.MediaSession
import coil.ImageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Plays with the screen off and gives lock-screen, headphone, widget and Android Auto controls.
 * In the car you browse Kö, Nytt and Poddar.
 */
class PlaybackService : MediaLibraryService() {
    private var session: MediaLibrarySession? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val handler = Handler(Looper.getMainLooper())
    private var artUrl: String? = null
    private var art: Bitmap? = null
    private var libCache: Library? = null
    private var libAt = 0L
    private var lastId: String? = null
    private var endSkippedFor: String? = null
    private var ticks = 0

    private fun library(fresh: Boolean = false): Library {
        val now = SystemClock.elapsedRealtime()
        val cached = libCache
        if (!fresh && cached != null && now - libAt < 60_000L) return cached
        val lib = Library.load(this)
        libCache = lib
        libAt = now
        return lib
    }

    // ---------- player events: widget, and progress while the app's screen is closed ----------

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            if (events.containsAny(
                    Player.EVENT_MEDIA_ITEM_TRANSITION,
                    Player.EVENT_IS_PLAYING_CHANGED,
                    Player.EVENT_MEDIA_METADATA_CHANGED,
                    Player.EVENT_POSITION_DISCONTINUITY,
                )
            ) {
                updateWidget(player)
            }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val prev = lastId
            val now = mediaItem?.mediaId
            lastId = now
            if (PlaybackHub.appActive) return
            val auto = reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO
            if (!auto && reason != Player.MEDIA_ITEM_TRANSITION_REASON_SEEK) return
            updateState(now) { queue, played, positions ->
                if (auto && prev != null) {
                    played.add(prev)
                    positions.remove(prev)
                }
                if (now != null) queue.remove(now)
            }
            val lib = library(fresh = true)
            val e = now?.let { lib.byId[it] } ?: return
            val start = lib.startPos(this@PlaybackService, e)
            if (start > 0L) session?.player?.seekTo(start)
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (!isPlaying && !PlaybackHub.appActive) savePosition()
        }
    }

    private fun updateState(newCurrent: String? = null, change: (MutableList<String>, MutableSet<String>, MutableMap<String, Long>) -> Unit) {
        runCatching {
            val s = Store.loadState(this)
            val q = s.queue.toMutableList()
            val pl = s.played.toMutableSet()
            val pos = s.positions.toMutableMap()
            change(q, pl, pos)
            Store.saveState(this, q, pl, pos, newCurrent ?: s.current)
        }
    }

    private fun savePosition() {
        val p = session?.player ?: return
        val id = p.currentMediaItem?.mediaId ?: return
        val ms = p.currentPosition
        if (ms > 0L) updateState { _, _, positions -> positions[id] = ms }
    }

    private val tick = object : Runnable {
        override fun run() {
            runCatching { checkSkipEnd() }
            handler.postDelayed(this, 1_000L)
        }
    }

    /** "Skip the end" when the app's screen is closed (in the car, from the widget). */
    private fun checkSkipEnd() {
        if (PlaybackHub.appActive) return
        val p = session?.player ?: return
        if (!p.isPlaying) return
        val id = p.currentMediaItem?.mediaId ?: return
        ticks++
        if (ticks % 15 == 0) savePosition()
        val e = library().byId[id] ?: return
        val skip = Library.skipEndOf(this, e.feedUrl) * 1000L
        val dur = p.duration
        if (skip <= 0L || dur <= skip + 10_000L || endSkippedFor == id) return
        if (p.currentPosition < dur - skip) return
        endSkippedFor = id
        updateState { _, played, positions ->
            played.add(id)
            positions.remove(id)
        }
        if (p.hasNextMediaItem()) p.seekToNextMediaItem() else p.pause()
    }

    // ---------- the library the car browses ----------

    private fun folder(id: String, title: String, type: Int, artwork: String? = null): MediaItem {
        val md = MediaMetadata.Builder()
            .setTitle(title)
            .setIsBrowsable(true)
            .setIsPlayable(false)
            .setMediaType(type)
        if (!artwork.isNullOrEmpty()) md.setArtworkUri(Uri.parse(artwork))
        return MediaItem.Builder().setMediaId(id).setMediaMetadata(md.build()).build()
    }

    private fun rootItem() = folder(ROOT, "Podbacken", MediaMetadata.MEDIA_TYPE_FOLDER_MIXED)

    private fun folderFor(id: String, lib: Library): MediaItem? = when {
        id == ROOT -> rootItem()
        id == QUEUE -> folder(QUEUE, "Kö", MediaMetadata.MEDIA_TYPE_FOLDER_PODCASTS)
        id == LATEST -> folder(LATEST, "Nytt", MediaMetadata.MEDIA_TYPE_FOLDER_PODCASTS)
        id == PODS -> folder(PODS, "Poddar", MediaMetadata.MEDIA_TYPE_FOLDER_PODCASTS)
        id.startsWith(POD) -> lib.podcast(id.removePrefix(POD))?.let { folder(id, it.title, MediaMetadata.MEDIA_TYPE_PODCAST, it.imageUrl) }
        else -> null
    }

    private fun childrenOf(parentId: String, lib: Library): List<MediaItem> {
        val ctx = this
        return when {
            parentId == ROOT -> listOfNotNull(folderFor(QUEUE, lib), folderFor(LATEST, lib), folderFor(PODS, lib))
            parentId == QUEUE -> lib.state.queue.mapNotNull { lib.byId[it] }.map { lib.playable(ctx, it) }
            parentId == LATEST -> lib.latest().map { lib.playable(ctx, it) }
            parentId == PODS -> lib.podcasts.map { folder(POD + it.feedUrl, it.title, MediaMetadata.MEDIA_TYPE_PODCAST, it.imageUrl) }
            parentId.startsWith(POD) -> lib.episodesOf(ctx, parentId.removePrefix(POD)).map { lib.playable(ctx, it) }
            else -> emptyList()
        }
    }

    private val callback = object : MediaLibrarySession.Callback {
        override fun onGetLibraryRoot(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            params: LibraryParams?,
        ): ListenableFuture<LibraryResult<MediaItem>> =
            Futures.immediateFuture(LibraryResult.ofItem(rootItem(), params))

        override fun onGetItem(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            mediaId: String,
        ): ListenableFuture<LibraryResult<MediaItem>> {
            val lib = library()
            val item = folderFor(mediaId, lib) ?: lib.byId[mediaId]?.let { lib.playable(this@PlaybackService, it) }
            val result: LibraryResult<MediaItem> =
                if (item != null) LibraryResult.ofItem(item, null) else LibraryResult.ofError(LibraryResult.RESULT_ERROR_BAD_VALUE)
            return Futures.immediateFuture(result)
        }

        override fun onGetChildren(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            parentId: String,
            page: Int,
            pageSize: Int,
            params: LibraryParams?,
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> {
            val lib = library(fresh = parentId == ROOT || parentId == QUEUE)
            val all = childrenOf(parentId, lib)
            val paged = if (pageSize in 1..10_000) all.drop(page.coerceAtLeast(0) * pageSize).take(pageSize) else all
            return Futures.immediateFuture(LibraryResult.ofItemList(paged, params))
        }

        /** Items from the app are ready to play; items from the car only carry an id. */
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
        ): ListenableFuture<MutableList<MediaItem>> {
            if (mediaItems.all { it.localConfiguration != null }) return Futures.immediateFuture(mediaItems)
            val lib = library()
            val resolved = mediaItems.mapNotNull { item ->
                if (item.localConfiguration != null) item else lib.byId[item.mediaId]?.let { lib.playable(this@PlaybackService, it) }
            }.toMutableList()
            return Futures.immediateFuture(resolved)
        }

        /** Picking an episode in the car: play it from where you left off, then the rest of the queue. */
        override fun onSetMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
            startIndex: Int,
            startPositionMs: Long,
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
            if (mediaItems.all { it.localConfiguration != null }) {
                return Futures.immediateFuture(MediaSession.MediaItemsWithStartPosition(mediaItems, startIndex, startPositionMs))
            }
            val lib = library(fresh = true)
            val ctx = this@PlaybackService
            val picked = mediaItems.getOrNull(startIndex.coerceAtLeast(0)) ?: mediaItems.firstOrNull()
            val e = picked?.let { lib.byId[it.mediaId] }
                ?: return Futures.immediateFailedFuture(UnsupportedOperationException("Okänt avsnitt"))
            val q = lib.state.queue
            val after = if (e.id in q) q.drop(q.indexOf(e.id) + 1) else q
            val items = listOf(lib.playable(ctx, e)) + after.filter { it != e.id }.mapNotNull { lib.byId[it] }.map { lib.playable(ctx, it) }
            return Futures.immediateFuture(MediaSession.MediaItemsWithStartPosition(items, 0, lib.startPos(ctx, e)))
        }

        /** Play on the steering wheel or headphones with nothing loaded: the last episode. */
        override fun onPlaybackResumption(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
        ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
            val lib = library(fresh = true)
            val e = PodWidget.lastId(this@PlaybackService)?.let { lib.byId[it] }
                ?: return Futures.immediateFailedFuture(UnsupportedOperationException("Inget att återuppta"))
            val ctx = this@PlaybackService
            return Futures.immediateFuture(MediaSession.MediaItemsWithStartPosition(listOf(lib.playable(ctx, e)), 0, lib.startPos(ctx, e)))
        }
    }

    // ---------- life cycle ----------

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_SPEECH).build(),
                true,
            )
            .setHandleAudioBecomingNoisy(true)
            .setSeekBackIncrementMs(15_000)
            .setSeekForwardIncrementMs(30_000)
            .build()
        player.addListener(listener)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        session = MediaLibrarySession.Builder(this, player, callback).setSessionActivity(open).build()
        handler.postDelayed(tick, 1_000L)
    }

    private fun updateWidget(p: Player) {
        val item = p.currentMediaItem ?: return
        val md = item.mediaMetadata
        val url = md.artworkUri?.toString()
        PodWidget.remember(
            this, item.mediaId, item.localConfiguration?.uri?.toString() ?: "",
            md.title?.toString() ?: "", md.artist?.toString() ?: "", url ?: "",
            p.currentPosition, p.isPlaying,
        )
        if (url != artUrl) {
            artUrl = url
            art = null
            if (url != null) {
                scope.launch {
                    val bmp = loadArt(url)
                    if (artUrl == url) {
                        art = bmp
                        PodWidget.render(this@PlaybackService, bmp)
                    }
                }
            }
        }
        PodWidget.render(this, art)
    }

    private suspend fun loadArt(url: String): Bitmap? = runCatching {
        val req = ImageRequest.Builder(this).data(url).size(240).allowHardware(false).build()
        val result = ImageLoader(this).execute(req)
        (result as? SuccessResult)?.drawable?.toBitmap(240, 240)
    }.getOrNull()

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        val p = session?.player
        if (!PlaybackHub.appActive) savePosition()
        PodWidget.markStopped(this, p?.currentPosition)
        PodWidget.render(this, art)
        scope.cancel()
        session?.run {
            player.removeListener(listener)
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }

    companion object {
        private const val ROOT = "root"
        private const val QUEUE = "queue"
        private const val LATEST = "latest"
        private const val PODS = "pods"
        private const val POD = "pod:"
    }
}
